package Guia_1;
import java.util.Scanner;

public class main{

    public static void main(String[] args) {

        Scanner lector = new Scanner(System.in);
        System.out.println("Hola mundo");


    }
}
