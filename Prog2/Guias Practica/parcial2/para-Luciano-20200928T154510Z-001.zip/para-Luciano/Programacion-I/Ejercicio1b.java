package Guia_1;

public class Ejercicio1b {
    public static void main(String[] args){
        double x = 10;
        double a = 5;

        double result = (a *Math.pow(x,2)) - 5 * x + 10;
                System.out.println("El resultado de la suma es: " +result);
    }
}
