package com.company;

import javax.swing.*;

public class Programa {
    public static void main(String[] args){

        Articulo articulo_1 = new Articulo("Samsumg S10",9000);
        Articulo articulo_2 = new Articulo("Iphone X",12000);
        Articulo articulo_3 = new Articulo("Samsumg S8",5000);

        System.out.println(articulo_1.calcularmmayor());
        System.out.println(articulo_2.calcularmenor());
        System.out.println(articulo_3.calcularmenor());

    }
}
