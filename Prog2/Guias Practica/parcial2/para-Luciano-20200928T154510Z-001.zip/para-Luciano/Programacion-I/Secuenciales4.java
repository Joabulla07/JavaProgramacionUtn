import java.util.Scanner;
public class Secuenciales4 {
    public static void main(String[] args){
        double sueldototal;
        double horasxx;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese el total de horas que no sean extras trabajadas.");
        int horas = lector.nextInt();
        System.out.println("Ingrese el total de horas extra");
        int horasx = lector.nextInt();
        System.out.println("Ingrese el sueldo por hora del empleado.");
        double sueldohora = lector.nextDouble();
        horasxx = horasx * 2;
        sueldototal = sueldohora * horas + sueldohora * horasxx;
        System.out.println("El total a pagar al empelado es: "+sueldototal);

    }
}
