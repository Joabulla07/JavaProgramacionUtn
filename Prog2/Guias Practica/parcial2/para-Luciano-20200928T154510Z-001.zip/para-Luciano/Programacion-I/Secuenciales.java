import java.util.Scanner;

public class Secuenciales {
    public static void main(String[] args){
        double result;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese el valor de X: ");
        double x = lector.nextDouble();
        System.out.println("Ingrese el valor de A: ");
        double a = lector.nextDouble();

        double powx = Math.pow(x , 2);
        result = (a * powx) - 5 * x + 10;

        System.out.println("El valor de la operacion es:  "+result);

    }
}