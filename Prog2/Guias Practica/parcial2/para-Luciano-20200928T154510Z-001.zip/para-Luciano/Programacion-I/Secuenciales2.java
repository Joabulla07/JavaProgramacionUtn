import java.util.Scanner;
public class Secuenciales2 {
    public static void main(String[] args){
        Scanner lector = new Scanner (System.in);

        double precioxkm = 10.50;
        double preciototal;
        System.out.println("Ingrese la cantidad de Kilometros que recorrio.");
        double kms = lector.nextDouble();
        preciototal = kms * precioxkm;
        System.out.println(" Su importe por boleto es de: " +preciototal+"Bs.");


    }

}
