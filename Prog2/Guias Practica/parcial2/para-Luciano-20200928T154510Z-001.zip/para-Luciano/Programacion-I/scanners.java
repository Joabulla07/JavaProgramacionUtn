import java.util.Scanner;

public class scanners{

	public static void main(String[] args){
		Scanner detector = new Scanner(System.in);
		// Si quiero leer una string/cadena de caracteres.
		String nombre = detector.nextLine();
		// si quiero leer un caracter ingresado por teclado
		char sexo = detector.next().charAt(0);
		// Si quiero leer un entero ingresado por teclado
		int edad = detector.nextInt();
		// Si quiero leer un long ingresado por teclado
		long numtel = detector.nextLong();
		// Si quiero leer un double ingresado por teclado
		double numdoc = detector.nextDouble();
		// Si quiero leer un float ingresado por teclado
		float pi = detector.nextFloat();
	}
}