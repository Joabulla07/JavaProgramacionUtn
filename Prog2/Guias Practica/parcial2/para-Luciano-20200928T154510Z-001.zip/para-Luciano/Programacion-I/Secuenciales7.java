/* Un profesor desea saber qué porcentaje de hombres y qué porcentaje de mujeres hay en
un grupo de estudiantes */

import java.util.Scanner;

public class Secuenciales7 {
    public static void main(String[] args){
        double total;
        double porcentajemuj;
        double porcentajehom;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de hombres en el grupo.");
        double hom = lector.nextInt();
        System.out.println("Ingrese la cantidad de mujeres en el grupo");
        double muj = lector.nextInt();
        total = hom + muj;
        porcentajehom = (hom * 100) / total;
        porcentajemuj = (muj * 100) / total;
        System.out.println("El porcentaje de Hombres es = " +porcentajehom);
        System.out.printf("El porcentaje de Mujeres es = " +porcentajemuj);
    }
}
