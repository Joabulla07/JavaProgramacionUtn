import java.util.Scanner;

public class Secuenciales6 {
    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese un numero de un solo digito.");
        int d1 = lector.nextInt();
        System.out.println("Ingrese un segundo numero de un solo digito");
        int d2 = lector.nextInt();
        System.out.println("Ingrese un tercer numero de un solo digito");
        int d3 = lector.nextInt();

        System.out.println("Su numero es: "+d1+d2+d3);
    }
}
