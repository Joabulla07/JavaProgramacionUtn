package Guia_1;
import java.util.Scanner;

public class Ejercicio1a {
    public static void main(String[] args){
    float x = 10;
    float y = 5;
    float z = 2;

    float result1 = (x+y)/z;
        System.out.println("El resultado es: "+result1);


    }
}

