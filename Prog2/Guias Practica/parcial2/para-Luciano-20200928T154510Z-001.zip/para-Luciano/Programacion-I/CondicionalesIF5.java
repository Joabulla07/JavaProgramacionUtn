import java.util.Scanner;

public class CondicionalesIF5 {
    public static void main(String[] args){
        /*Dados los lados de un triángulo, informar qué tipo es: isósceles, escaleno o equilátero. */
        int a,b,c;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese los lados del triangulo a comparar.");
        a = lector.nextInt();
        b = lector.nextInt();
        c = lector.nextInt();
        if (a == b && a == c){
            System.out.println("Dado los datos ingresados, su triangulo es Equilatero.");

        } else if ((a == b && a != c) || (a != b && a == c)){
            System.out.println("Dado los datos ingresados, su triangulo es Isoceles.");
        } else if (a != b && a != c && b != c){
            System.out.println("Dado los datos ingresados, su triangulo es Escaleno");
        }
    }
}
