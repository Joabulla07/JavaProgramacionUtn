import com.sun.org.apache.xpath.internal.SourceTree;

import java.util.Scanner;

public class CondicionalesIF4 {
    public static void main(String[] args) {
        int x, y, z;
        System.out.println("Ingrese 3 numeros enteros.");
        Scanner lector = new Scanner(System.in);

        x = lector.nextInt();
        y = lector.nextInt();
        z = lector.nextInt();

        if (x > y && x > z) {
            System.out.println("El primer numero es mayor que todos los demas, numero ingresado: " + x);
        } else if (y > x && y > z) {
            System.out.println("El segundo numero es mayor que todos los demas, numero ingresado: " + y);
        } else if (z > x && z > y) {
            System.out.println("El tercer numero es mayor que todos los demas, numero ingresado: " + z);
        }
    }
}