public class MiPrimerApp {
	 public static void main(String[] args) {
		
		System.out.println ("Yo ruleo bro");
		System.out.println ("ah, de nazi");

	}

}