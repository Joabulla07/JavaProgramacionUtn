package Guia_1;

public class Ejercicio2b {

    public static void main(String[] args){
        float x = 4;
        float y = (x / 2);
        float result = y + 12;
        float z = result % 3;
        System.out.println("El resultado de la operacion es: "+z);
    }
}
