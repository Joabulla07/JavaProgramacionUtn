import java.util.Scanner;
public class t2a {
// Ejercicio numero 2:
    public static void main(String[] args){
        int x1 = 10;
        int y1 = 5;
        int z1 = x1 + y1 * 2;

        System.out.println("El resultado del ejercicio A es: "+z1);

        float x2 = 4;
        float y2 = (x2 / 2);
        float z2 = y2 + 12;
        z2 = z2 % 3;

        System.out.println("El resultado del ejercicio B es: "+z2);
        int x3 = 120;
        int y3 = ((x3 * 2)-5);
        int z3;

        x3 = x3 - 10;

        z3 = x3 + y3 - x3 - x3 +2;

        System.out.println("El resultado del ejercicio C es: "+z3);

        double a4 = 1.3;
        double x4 = 0;
        double y4 = 8;
        double z4;

      z4 = a4 + y4 * 2 - (x4 / 3);
      x4 = x4 + 2;
      z4 = (z4 - x4) * 1.2;

        System.out.println("El resultado del ejercicio D es: "+z4);

        double a5 = 2.5;
        double j5 = 2;
        double b5 = Math.pow(a5,j5);
        double i = 2 * j5;
        double l = j5 * i;
        double z5 = a5 + b5;

        System.out.println("El resultado del ejercicio E es: "+z5);


    }
}

