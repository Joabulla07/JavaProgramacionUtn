package Guia_1;

public class Ejercicio1c {
    public static void main(String[] args){
        float r = 10;
        float a = 4;
        float b = 3;
        float result =  (a/b) * r;
        System.out.println("El resultado de la operacion es " +result);
    }
}
