import java.io.PrintStream;
import java.util.Scanner;

public class CondicionalesIF1 {
    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);
        double promedio;
        System.out.println("Ingrese la calificacion del primer examen.");
        double n1 = lector.nextDouble();
        System.out.println("Ingrese la calificacion del segundo examen.");
        double n2 = lector.nextDouble();
        System.out.println("Ingrese la calificacion del tercer examen.");
        double n3 = lector.nextDouble();
        promedio = (n1 + n2 + n3) / 3;
        if (promedio > 60){
            System.out.println("El alumno aprobo.");
            System.out.println("El promedio de notas del alumno es de: "+promedio);
        } else {
            System.out.println("El alumno desaprobo.");
            System.out.println("El promedio de notas del alumno es de: "+promedio);
        }

    }
}
