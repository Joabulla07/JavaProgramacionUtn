package Parcial;

public class Empleado {
    private String nombre;
    private String cuit;
    private int edad;
    private boolean casado;
    private double salario_base;


    public Empleado(String nombre, String cuit, int edad, boolean casado) {
        this(nombre,cuit,edad,casado,8000);
    }

    public Empleado(String nombre, String cuit, int edad, boolean casado, double salario_base) {
        this.nombre = nombre;
        this.cuit = cuit;
        this.edad = edad;
        this.casado = casado;
        this.salario_base = salario_base;
    }
    public char antiguedad(int edad){
        if (edad <= 21){
            return 'C';
        }
        else if (edad >= 22 && edad <= 35){
            return 'B';

        }else{
            return 'A';
        }
    }
    public double aumentarSalario(){
        if (antiguedad(edad) == 'A'){
            return salario_base*0.20;
        }else if(antiguedad(edad) == 'B'){
            return salario_base*0.10;
        }
        else
        {
            return salario_base*0.05;
        }
    }

    public double getSalario_base() {
        return salario_base;
    }
}
