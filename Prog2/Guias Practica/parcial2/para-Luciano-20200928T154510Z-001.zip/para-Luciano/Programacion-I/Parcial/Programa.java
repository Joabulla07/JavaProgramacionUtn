package Parcial;

import java.util.Scanner;

public class Programa {
    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);
        String nombre;
        String cuit;
        int edad;
        boolean casado;
        double salariobase;

        Empleado empleado1 = new Empleado("Mauricio Benitez", "20-434050-96",23,false);
        Empleado empleado2 = new Empleado("German Bautista", "21-54234-36",35,true);
        Empleado empleado3 = new Empleado("Zeniquel Fernando", "40-434050-32",18,false);
        Empleado empleado4 = new Empleado("Blas Cabat Geat", "31=46823432-0",30,false);
        Empleado array[] = new Empleado[4];
        array[1] = new Empleado("Mauricio Benitez", "20-434050-96",23,false);
        array[2] = new Empleado("German Bautista", "21-54234-36",35,true);
        array[3] = new Empleado("Zeniquel Fernando", "40-434050-32",18,false);
        array[4] = new Empleado("Blas Cabat Geat", "31=46823432-0",30,false);
        for (int i = 0; i <= 3; i++){
            System.out.println(array[i]);
        }

    }
}
