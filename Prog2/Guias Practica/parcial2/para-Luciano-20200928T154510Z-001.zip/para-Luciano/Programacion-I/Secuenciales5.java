import java.util.Scanner;

public class Secuenciales5 {
    public static void main(String[] args){
        double result1;
        double result2;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese el primer valor.");
        double a = lector.nextDouble();
        System.out.println("Ingrese el segundo valor.");
        double b = lector.nextDouble();

        result1 = (2*a) + Math.pow(b,2);
        result2 = (((Math.pow(a,3)) + (Math.pow(b,3)))/3);

        System.out.println("La suma del doble del primero mas el cuadrado del segundo es: "+result1);
        System.out.println("El promedio de los cubos de los numeros ingresado es:"+result2);
    }
}
