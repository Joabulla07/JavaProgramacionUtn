package Ejercicio2OOP;

public class Persona {
    protected final static String AP_DEF = " ";
    protected final static int ED_DEF = 0;
    protected final static char SE_DEF = 'h';
    protected final static float PE_DEF = 0f;
    protected final static float AL_DEF = 0f;
    protected final static int IMC_NEG = -1;
    protected final static int IMC_NOR = 0;
    protected final static int IMC_POS = 1;

    private String nombre; // no hay por defecto
    private String apellido;
    private int edad;
    private int dni; // no hay por defecto
    private char sexo;
    private float peso;
    private float altura;

    public Persona(String nombre, int dni) {
        this(nombre,AP_DEF,ED_DEF,dni,SE_DEF,PE_DEF,AL_DEF);
    }

    public Persona(String nombre, String apellido, int edad, int dni, char sexo) {
        this(nombre,apellido,edad,dni,sexo,PE_DEF,AL_DEF);
    }

    public Persona(String nombre, String apellido, int edad, int dni, char sexo, float peso, float altura) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.dni = dni;
        this.sexo = sexo;
        this.peso = peso;
        this.altura = altura;
    }
    public int calcularIMC(float peso, float altura){
        float imc;
        imc = peso / (altura * altura);
        if (imc < 20 ){
            return IMC_NEG;
        }else if (imc >= 20 && imc <= 25){
            return IMC_NOR;
        }else{
            return IMC_POS;
        }

    }
    public boolean esMayordeEdad(int edad){
        if (edad >= 18){
            return true;
        }else{
            return false;
        }
    }
    private char comprobarSexo(char sexo){
        if (sexo == 'h' || sexo == 'H'){
            return 'h';
        }else if(sexo == 'm' || sexo == 'M'){
            return 'm';
        }else{
            return 'h';
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "Datos de la Persona:  " +
                " \nNombre: " + nombre +
                " \nApellido: " + apellido +
                " \nEdad: " + edad +
                " \nDni: " + dni +
                " \nSexo: " + sexo +
                " \nPeso: " + peso +
                " \nAltura: " + altura
                ;

    }
}
