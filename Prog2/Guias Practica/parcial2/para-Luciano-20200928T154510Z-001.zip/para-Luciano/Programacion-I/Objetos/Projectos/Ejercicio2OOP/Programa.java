package Ejercicio2OOP;

import javax.swing.*;

public class Programa {
    public static void main(String[] args){
        String nombre;
        String apellido;
        int dni;
        int edad;
        String sexo1;
        char sexo;
        float peso;
        float altura;
        nombre = JOptionPane.showInputDialog("Ingrese su nombre: ");
        apellido = JOptionPane.showInputDialog("Ingrese su apellido: ");
        dni = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su DNI: "));
        edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad: "));
        sexo1 = JOptionPane.showInputDialog("Ingrese su Sexo: Hombre/Mujer ");
        sexo = sexo1.charAt(0);
        peso = Float.parseFloat(JOptionPane.showInputDialog("Ingrese su peso: "));
        altura = Float.parseFloat(JOptionPane.showInputDialog("Ingrese su altura: "));


        Persona persona1 = new Persona(nombre,apellido,dni,edad,sexo,peso,altura);
        if (persona1.calcularIMC(peso,altura) == -1){
            JOptionPane.showMessageDialog(null,"Su peso esta por debajo de los valores ideales de los estandares de IMC.");
        }else if(persona1.calcularIMC(peso,altura) == 0){
            JOptionPane.showMessageDialog(null,"Su peso esta en los valores ideales de los  estandares de IMC");
        }else{
            JOptionPane.showMessageDialog(null,"Su peso supera los valores ideales estandares de IMC");
        }
        if (persona1.esMayordeEdad(edad)){
            JOptionPane.showMessageDialog(null,"Usted es mayor de edad.");
        }else if (!persona1.esMayordeEdad(edad)){
            JOptionPane.showMessageDialog(null,"Usted es menor de edad");
        }
        JOptionPane.showMessageDialog(null,persona1.toString());

    }
}
