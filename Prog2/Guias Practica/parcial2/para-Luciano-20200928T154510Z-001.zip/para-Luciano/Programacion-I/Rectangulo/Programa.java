package Rectangulo;

import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        double base, altura;
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese base");
        base = sc.nextDouble();
        System.out.println("Ingrese altura");
        altura = sc.nextDouble();

        Rectangulo rec1 = new Rectangulo(base, altura);
        rec1.Area(base, altura);
        rec1.Perimetro(base, altura);
        rec1.setTest(3);
        double area1 = rec1.Area(base, altura) + rec1.getTest();

        System.out.println(rec1);

    }
}
