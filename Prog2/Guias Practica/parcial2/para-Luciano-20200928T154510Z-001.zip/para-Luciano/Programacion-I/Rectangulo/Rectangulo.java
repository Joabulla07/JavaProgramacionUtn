package Rectangulo;

public class Rectangulo{

    private double base;
    private double altura;
    private double test = 9;

    public Rectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    public double Area(double base, double altura){
       return this.base*this.altura;
    }

    public double Perimetro(double base, double altura){
        return (this.base*2) + (this.altura*2);
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getTest() {
        return test;
    }

    public void setTest(double test) {
        this.test = test;
    }

    @Override
    public String toString() {
        return "Rectangulo{" +
                "base=" + base +
                ", altura=" + altura +
                ", test=" + test +
                '}';
    }
}
