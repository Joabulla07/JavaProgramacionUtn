package Guia_1;

public class Ejercico2a {
    public static void main (String[] args){

        int x = 10;
        int y = 5;

        int result = x + y * 2;
                System.out.println("Ël resultado de la operacion es: "+result);

    }

}
