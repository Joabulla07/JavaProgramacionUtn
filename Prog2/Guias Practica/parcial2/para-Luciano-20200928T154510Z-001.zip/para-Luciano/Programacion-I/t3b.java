import java.util.Scanner;

public class t3b {

    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);

        int i = 7;
        float f = 5.f;
        char c = 'w';

        boolean vari1 = (i >= 6) && (c == 'w');
        System.out.println("El ejercicio a es: " +vari1);

        boolean vari2 = (i >= 6) || (c==119);
        System.out.println("El ejercicio b es: "+vari2);

        boolean vari3 = (f < 100) && (i > 100);
        System.out.println("El ejercicio c es: "+vari3);

        boolean vari4 = (c != 'p') || ((i + f) <= 10);
        System.out.println("El ejercicio d es: "+vari4);

        boolean vari5 = i + f <= 10;
        System.out.println("El ejercicio e es: "+vari5);

        boolean vari6 = i >= 6 && c == 'w';
        System.out.println("El ejercicio f es: "+vari6);

        boolean vari7 = c != 'p' || i + f  <= 10;
        System.out.println("El ejercicio g es: "+vari7);

    }
}
