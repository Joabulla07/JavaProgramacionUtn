import java.util.Scanner;

public class test {
    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese un numero: " );
        int numero = lector.nextInt();
        System.out.println("El numero ingresado es de: ");
    }
}
