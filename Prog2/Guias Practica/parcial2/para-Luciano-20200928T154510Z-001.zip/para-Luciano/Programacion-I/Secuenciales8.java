import java.util.Scanner;

public class Secuenciales8 {
    public static void main(String[] args){
        double pulgadas = 0.39737;
        double total;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese el numero de Centimetros a convertir: ");
        int cms = lector.nextInt();
        total = pulgadas * cms;
        System.out.println("El numero ingresado de Centimetros convertido en pulgadas es: "+total);



    }
}
