package com.company;

public class Articulo {

    private String nombre;
    private double precioBase;

    public Articulo(String nombre, double precioBase)
    {
        this.nombre= nombre;
        this.precioBase = precioBase;
    }
    public double calcularmenor() {
        return this.precioBase + (this.precioBase * 0.30);
    }
    public double calcularmmayor(){

        return  this.precioBase+(this.precioBase*0.15);
    }
    @Override
    public String toString(){
        return "Articulo{" +
                "precioBase=" + precioBase +
                '}';
    }
}
