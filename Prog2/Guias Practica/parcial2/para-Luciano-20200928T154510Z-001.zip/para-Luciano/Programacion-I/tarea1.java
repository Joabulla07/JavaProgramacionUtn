import java.util.Scanner;

public class tarea1{


	public static void main(String[] args) {

		System.out.println("Ingrese su nombre de usuario:");
        Scanner scanner = new Scanner(System.in);
        String user = scanner.nextLine();
		System.out.println("Hola mundo + "+user);
	}
}
