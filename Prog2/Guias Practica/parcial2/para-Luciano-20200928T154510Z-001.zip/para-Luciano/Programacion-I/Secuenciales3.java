import java.util.Scanner;
public class Secuenciales3 {

    public static void main(String[] args){

        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese el monto presupuestario a calcular");
        double presupuesto = lector.nextDouble();

        double Urgencias = (presupuesto * 37) / 100;
        double Pediatria = (presupuesto * 42) / 100;
        double Traumatologia = (presupuesto * 21) / 100;

        System.out.println("El area de Urgencias recibira un total de: "+Urgencias);
        System.out.println("El area de Pediatria recibira un total de: "+Pediatria);
        System.out.println("El area de Traumatologia recibira un total de: "+Traumatologia);

    }
}
