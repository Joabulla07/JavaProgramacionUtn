public class MiPrimeraSuma {

	 public static void main(String[] args) {

	 	int tuvieja;
	 	int x;
	 	int resultado;
	 	tuvieja = 4;
	 	x = 10;
	 	resultado = x - tuvieja;

	 	

	 	System.out.println ("tu numero es: ");
	 	System.out.println (resultado);
		
	}
}

