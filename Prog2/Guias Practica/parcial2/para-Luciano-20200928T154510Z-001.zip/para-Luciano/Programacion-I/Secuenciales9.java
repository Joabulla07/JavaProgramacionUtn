import java.util.Scanner;

public class Secuenciales9 {
    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);
        int totalmuj,totalhom,totaltotal,promediohom,promediomuj;
        double porcenhom,porcenmuj;


        System.out.println("Ingrese la cantidad de hombres de la Comision 1 ");
        int hom1 = lector.nextInt();
        System.out.println("Ingrese la cantidad de hombres de la Comision 2");
        int hom2 = lector.nextInt();
        System.out.println("Ingrese la cantidad de hombres de la Comision 3");
        int hom3 = lector.nextInt();
        System.out.println("Ingrese la cantidad de mujeres de la Comision 1");
        int muj1 = lector.nextInt();
        System.out.println("Ingrese la cantidad de mujeres de la Comision 2");
        int muj2 = lector.nextInt();
        System.out.println("Ingrese la cantidad de mujeres de la Comision 3");
        int muj3 = lector.nextInt();

        totalhom = hom1 + hom2 + hom3;
        totalmuj = muj1 + muj2 + muj3;
        promediohom = totalhom / 3;
        promediomuj = totalmuj / 3;
        totaltotal = totalhom + totalmuj;
        porcenhom = (totalhom * 100) / totaltotal;
        porcenmuj = (totalmuj * 100) / totaltotal;

        System.out.println("El total de hombres en las 3 Comisiones es de: "+totalhom);
        System.out.println("El total de mujeres en las 3 comisiones es de: "+totalmuj);
        System.out.println("El promedio de hombres en las 3 Comisiones es de: "+promediohom);
        System.out.println("El promedio de mujeres en las 3 Comisiones es de: "+promediomuj);
        System.out.println("El total de alumnos en las 3 Comisiones es de: "+totaltotal);
        System.out.println("El porcentaje de hombres con respecto al total de alumnos es de: "+porcenhom+"%");
        System.out.println("El porcentaje de mujeres con respecto al total de alumnos es de: "+porcenmuj+"%");
    }
}
