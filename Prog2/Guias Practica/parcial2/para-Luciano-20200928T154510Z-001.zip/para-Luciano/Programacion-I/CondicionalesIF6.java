import java.util.Scanner;

public class CondicionalesIF6 {
    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);
            int a;
        System.out.println("Ingrese un numero del 1 al 10.");
        a = lector.nextInt();
        switch (a){
            case 1:
                System.out.println("Su numero ingresado en romano es: I");
                break;
            case 2:
                System.out.println("Su numero ingresado en romano es de: II");
                break;
            case 3:
                System.out.println("Su numero ingresado en romano es de: III");
                break;
            case 4:
                System.out.println("Su numero ingresado en romano es de: IV");
                break;
            case 5:
                System.out.println("Su numero ingresado en romano es de: V");
                break;
            case 6:
                System.out.println("Su numero ingresado en romano es de: VI");
                break;
            case 7:
                System.out.println("Su numero ingresado en romano es de: VII");
                break;
            case 8:
                System.out.println("Su numero ingresado en romano es de: VIII");
                break;
            case 9:
                System.out.println("Su numero ingresado en romano es de: IX");
                break;
            case 10:
                System.out.println("Su numero ingreasdo en romano es de: X");
                break;
        }
    }
}
