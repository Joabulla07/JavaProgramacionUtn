import java.util.Scanner;
public class Secuenciales1 {

    public static void main(String[] args){

        int precioxkm = 45;
        double preciototal;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese cuantos kms se recorrio.");
        double km = lector.nextDouble();
        preciototal = precioxkm * km;
        System.out.println("El importe de su boleto es:  "+preciototal);

    }
}







































/* Estructuras secuenciales, repetitivas y condicionales
 Se utilizan para indicar el orden en que deben sucederse las acciones.
  */
