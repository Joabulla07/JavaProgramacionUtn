package Alumno;

public class Alumno {
    private int nroLegajo;
    private String nombreyapellido;
    private int nota1;
    private int nota2;
    private int nota3;

    public Alumno(int nroLegajo, String nombreyapellido, int nota1, int nota2, int nota3) {
        this.nroLegajo = nroLegajo;
        this.nombreyapellido = nombreyapellido;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }
    public double notaFinal(){
        return (this.nota1+this.nota2+this.nota3) / 3;

    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public void setNroLegajo(int nroLegajo) {
        this.nroLegajo = nroLegajo;
    }

    public String getNombreyapellido() {
        return nombreyapellido;
    }

    public void setNombreyapellido(String nombreyapellido) {
        this.nombreyapellido = nombreyapellido;
    }

    public int getNota1() {
        return nota1;
    }

    public void setNota1(int nota1) {
        this.nota1 = nota1;
    }

    public int getNota2() {
        return nota2;
    }

    public void setNota2(int nota2) {
        this.nota2 = nota2;
    }

    public int getNota3() {
        return nota3;
    }

    public void setNota3(int nota3) {
        this.nota3 = nota3;
    }


    @Override
    public String toString() {
        return "Los datos del alumno" +
                "\nSu numero de legajo = " + nroLegajo +
                "\nEl nombre y apellido del alumno = '" + nombreyapellido + '\'' +
                "\nSu primer nota = " + nota1 +
                "\nSu segunda nota = " + nota2 +
                "\nSu tercera nota = " + nota3 +
                '}';
    }
}
