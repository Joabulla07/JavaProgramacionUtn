package Alumno;

import java.util.Scanner;

public class Programa {
    public static void main(String[] args){
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese el numero de legajo del alumno.");
        int nroLegajo = lector.nextInt();
        System.out.println("Ingrese el nombre y apellido del alumno.");
        String nombreyapellido = lector.next();
        System.out.println("Ingrese el valor de la primer nota.");
        int nota1 = lector.nextInt();
        System.out.println("Ingrese el valor de la segunda nota.");
        int nota2 = lector.nextInt();
        System.out.println("Ingrese el valor de la tercera nota");
        int nota3 = lector.nextInt();

        Alumno alumno1 = new Alumno(nroLegajo,nombreyapellido,nota1,nota2,nota3);

        System.out.println(alumno1);

        System.out.println("La nota final del alumno es: "+alumno1.notaFinal());

        if (alumno1.notaFinal() >=6 ){
            System.out.println("El alumno aprobo la materia.");
        }else{
            System.out.println("El alumno desaprobo la materia.");
        }
    }
}
