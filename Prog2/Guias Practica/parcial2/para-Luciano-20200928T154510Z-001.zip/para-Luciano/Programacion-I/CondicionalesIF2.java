/* En un almacén se hace un 20% de descuento a los clientes cuya compra supere los $1000.
        Mostrar por pantalla cuál será la cantidad que pagará una persona por su compra. */

import java.util.Scanner;

public class CondicionalesIF2 {
    public static void main(String[] args){
        double preciototal;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese el monto para calcular.");
        double precio1 = lector.nextDouble();
        if (precio1 >= 1000){
            preciototal = precio1 * 0.20;
            System.out.println("El total a pagar es de: "+preciototal);
        }else{
            System.out.println("Al monto aplicado no es posible aplicar el descuento de cliente, el precio total a pagar es: "+precio1);
        }

    }
}
