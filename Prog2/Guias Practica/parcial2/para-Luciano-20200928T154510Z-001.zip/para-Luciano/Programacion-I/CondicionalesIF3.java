/*Solicitar la edad de dos hermanos, mostrando un mensaje que informe la edad del mayor
y cuántos años de diferencia tiene con el menor. */
import java.util.Scanner;

public class CondicionalesIF3 {
    public static void main(String[] args){
        int dif;
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese la edad del hermano mas grande.");
        int mayor = lector.nextInt();
        System.out.println("Ingrese la edad del hermano menor.");
        int menor = lector.nextInt();

        if (mayor > menor){
            System.out.println("La edad del mayor es: "+mayor);
            dif = mayor - menor;
            System.out.println("La diferencia de edad entre el mayor y el menor es: "+dif);
        }else{
            System.out.println("Datos ingresados incorrectamente.");
        }
    }
}
