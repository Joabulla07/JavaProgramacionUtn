package Guia_1;
import java.util.Scanner;
public class HolaMundo2 {
    public static void main(String[] args){

        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese su nombre de usuario");
        String user = lector.nextLine();
        System.out.println("Hola Mundo + "+user);

    }
}
