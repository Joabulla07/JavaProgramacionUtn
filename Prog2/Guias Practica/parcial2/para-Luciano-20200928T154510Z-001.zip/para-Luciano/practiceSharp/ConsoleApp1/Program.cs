﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Desarrollar una aplicacion en c# para
             * que dado un número de entrada calcule su correspondiente
             * tabla de multiplicar */

            Console.WriteLine("Input a integer: ");
            int i = Convert.ToInt32(Console.Read());
            
            
        }
    }
}