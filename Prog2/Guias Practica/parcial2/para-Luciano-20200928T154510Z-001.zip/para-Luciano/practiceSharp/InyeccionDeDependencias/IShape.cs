namespace PolimorfismoEInjeccionDeDependencias
{
    public interface IShape
    {
        public decimal GetArea();
        
    }
}