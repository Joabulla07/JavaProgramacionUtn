#include <stdio.h?
#define dim 10
/*se tiene un arreglo numerico de 10 elementos, se pide: 
1) todos los elementos del arreglo tienen que estar comprendidos entre 0 y 100 incluidos.
2) en caso de ingresar un elemeto que no corresponda, pedir nuevamente hasta completar la carga, mostrar por pantalla.
3) ordenar el arreglo de mayor a menor usando un procedimiento.
4) ingresar un elemento por teclado e indicar cuantas veces aparece en el arreglo.
*/
void imprimirArr(int arr[], int n);
void burbujaMayor(int arr[], int n);
int main(int argc, char *argv[]) {
	int arr1[dim];/*definicion de array dim = 10 usando define.*/
	int i=0,elemento,cont=0;/* definicion de variables y contadores necesarios para el programa.*/
	printf(">>A continuacion, ingrese los elementos comprendidos entre 0 y 100 para el array1: <<\n"); /* Obtencion de datos para el array 1S */ 
	for (i = 0; i < dim; i++){
		scanf("%d",&arr1[i]); /* lectura de datos y asignacion de dicho valor a la posicion i del array 1*/ 
		while (arr1[i] < 0 || arr1[i] > 100){ /* while encargado de filtrar datos no comprendidos entre 0 y 100 y buclear al usuario en caso de que siga intentando ingresar dichos valroes.*/
			printf(">>Error, elemento ingresado no comprende el intervalo 0-100, por favor, vuelva a ingresar un numero comprendido entre 0 y 100:  \n");
			scanf("%d",&arr1[i]);
		}
	}
	printf("Los valores del array son: ");
	imprimirArr(arr1,dim);/* muestra del arreglo por medio de un procedimiento */
	burbujaMayor(arr1,dim);/* llamado a procedimiento para ordenamiento por metodo de la burbuja  */
	printf(">>Los valores ordenados mayor a menor son: \n");
	imprimirArr(arr1,dim); /* muestra del arreglo  ya ordenado de mayor a menor por medio de un procedimiento */ 
	printf("\nIngrese el elemento a buscar cuantas veces se repite en el array 1.\n"); /* obtencion del valor elemento para comprobar si existe dicho elemento al recorrer el arreglo denuevo. */
	scanf("%d",&elemento);
	for (i = 0; i < dim; i++){
		if (arr1[i] == elemento){ /* condicion para sumar 1 al contador cada vez que el elemento i del arreglo es igual al elemento en busqueda. */ 
			cont++;
		}
	}
	printf("El numero %d se repite %d veces en el array 1.\n",elemento,cont); /* muestra de datos encontrados. */
	
	return 0;
}
/* funcion para imprimir un arreglo pasando el arreglo entero como argumento mas su dimension. */
void imprimirArr(int arr[], int n){
	int i;
	for (i = 0;i < n; i++){
		printf("%d ",arr[i]);
	}
	printf(" ");
}
/* Procedimiento para ordenar por metodo de ordenamiento burbuja un arreglo de dimension , pasando como argumentos el arreglo completo y su dimension. */
void burbujaMayor(int arr[], int n){
	int i, j, t;
	for (i = 0; i < n - 1; i++){
		for (j = 0; j < n - i - 1; j++){
			if (arr[j] < arr[j+1]){
				t = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = t;
			}
		}
		
	}
	
}
