#include <stdio.h>
#include <conio.h>
/* Usando la sentencia switch realizar un programa que permita introducir las medidas de un rectangulo
para calcular el perimetro y la superficie. mostrar los resultados por pantalla.
la operacion se repite hasta que el usuario desee salir y en cada repeticion se debe solicitar el ingreso de datos.
verificar que el ingreso de datos sea correcto para el calculo y documentar el programa.
*/
int main() {
	float b,h,superficie,perimetro;
	int opcion,bandera = 1;
	/* Declaracion  de datos que van a ser utilizados, tipo flotantes para la base y la altura ya que pueden ser datos decimales
	tipo entero para la opcion y la bandera ya que dichos valores no necesitan ser flotantes.*/
	printf("Bienvenido, este es un programa que al ingresar la base y la altura de un rectangulo, segun la opcion ingresada, devuelve el perimetro o la superficie\n");
	
	do{
		
		printf("Por favor, ingrese el valor de la altura del rectangulo.\n");
		scanf("%f",&h);
		/* Optencion del dato ALTURA */
		printf("Por favor, ingrese el valor de la base del rectangulo.\n");
		scanf("%f",&b);
		/* Obtencion del dato BASE */
		if (b > 0 && h > 0)
			/* Control de datos, la altura y la base no pueden ser 0.*/ {
			printf("Por favor, Ingrese que desea calcular con respecto a los datos del rectangulo introducidos.\n");
			printf("\n");
			printf(">>1. PERIMETRO\n");
			printf("\n");
			printf(">>2. SUPERFICIE\n");
			scanf("%d",&opcion);
			/* Obtencion de la opcion que quiere el usuario, ingreasndo un 1 devolvera el perimetro y ingresando un 2 devolvera la superficie.*/ 
			switch(opcion)
				/* Declaracion de la sentencia switch a utilizar, comandada por el ingreso de la opcion que quiera el usuario.*/
			{
			case 1: printf("Ingreso la opcion PERIMETRO\n");
			perimetro = ((b * 2) + (h * 2));
			/* Calculo del perimetro, se multiplica por 2 la base y por 2 la altura ya que tiene 2 alturas y 2 bases. */
			printf("El PERIMETRO de los valores del rectangulo ingresado es de: %.2f\n",perimetro);
			/* Muestra de la operacion. */
			break;
			/* Fin del case 1 para PERIMETRO */
			case 2: printf("Ingreso la opcion SUPERFICIE\n");
			superficie = (b * h);
			/* Calculo de la superficie, la formula es BASE x ALTURA para la obtencion de la superficie de un rectangulo.*/
			printf("la SUPERFICIE de los valores del rectangulo ingresado es de: %.2f\n",superficie);
			/* Muestra de la operacion. */ 
			break;
			default: printf("Opcion INCORRECTA, este programa solo admite 2 opciones, 1 para perimetro, 2 para superficie, por favor, ingrese una de estas 2 opciones.\n");
			}
			/* default para que en el caso de que el usuario ingrese algo diferente a 1 o 2, sea devuelto al ingreso de opcion */ 
			printf("Desea seguir usando el programa?\n");
			printf("\n");
			printf(">>INGRESE SU OPCION");
			printf("\n");
			printf(">>1. Si");
			printf("\n");
			printf(">>2 o cualquier otro numero = No\n");
			scanf("%d",&bandera);
			/* Declaracion y lectura de la variable encargada de la bandera del programa, si el usuario ingresa 1 el programa se repetira
			desde el ingreso de la base y la altura, si ingresa algo diferente a 1, el programa termina automaticamente.*/
		}else{printf(">>ERROR: Datos ingresados incorrectamente, por favor asegurese de que: La base sea mayor que la altura (dado que es un rectangulo) y que los valores sean mayores a 0.\n");
		/* Else encargado de asegurarse de que la base y la altura sean mayores a 0, en caso de que se ingrese cualquiera de estos 2 datos
		con 0, se mostrara este mensaje de error.*/}
	}while(bandera == 1);
	/* Fin de la bandera */ 
	return 0;
	/* Fin del programa*/
}
