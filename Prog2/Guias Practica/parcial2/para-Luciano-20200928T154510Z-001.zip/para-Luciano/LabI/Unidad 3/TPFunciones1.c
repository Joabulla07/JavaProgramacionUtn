#include <stdio.h>
#include <curses.h>
int suma(int a);
int main(){
    int i = 0,a,acum=0;
    for (i=0;i<=10;i++){
        printf("\nIngrese un numero");
        scanf("%d",&a);
        acum += suma(a);
        printf("El valor del acumulador hasta ahora es de: %d\n",acum);
    }
    
    return 0;
}
int suma(int a){
    int acum = 0;
    acum+=a;
    return acum;
}
