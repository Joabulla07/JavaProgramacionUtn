#include <stdio.h>
/*Ingresar n numeros por pantalla y calcular el producto de los mismos. 
Mostrar por pantalla los numeros ingresados y el resultado obtenido. El valor de n se ingresara� por pantalla.*/ 
int multi(int a, int b);
int main(int argc, char *argv[]) 
{
	int n,num1,num2,i=0,acum=0;
	printf("Ingrese la cantidad de multiplicaciones con 2 valores que se haran.\n");
	scanf("%d",&n);
	for (i = 0;i < n;i++){
		printf("Ingrese el primer valor.\n");
		scanf("%d",&num1);
		printf("Ingrese el segundo valor.\n");
		scanf("%d",&num2);
		if (i == 0){
			acum = acum + multi(num1,num2);
			printf("El resultado obtenido es de la multiplicacion entre %d y %d es: %d\n",num1,num2,acum);
		}else{
			acum = acum + multi(num1,num2);
			printf("Los numeros ingresados fueron: %d y %d\n\n",num1,num2);
			printf("El resultado obtenido entre %d, %d y sumado al resultado anterior es de: %d\n",num1,num2,acum);
		}
		
	}
	return 0;
}
int multi(int a, int b)
{
	int multitotal = 1;
	if (a == 0 || b == 0){
		return 0;
	}else{
		multitotal = multitotal * a * b;
		return multitotal;
	}
}
