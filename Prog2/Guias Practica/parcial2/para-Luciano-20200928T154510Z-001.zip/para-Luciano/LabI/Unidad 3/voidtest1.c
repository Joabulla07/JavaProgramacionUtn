#include <stdio.h>
void imprimevalor();
int main(int argc, char *argv[]) {
	int contador = 0;
	contador++;
	printf("El valor de contador es de %d\n",contador);
	imprimevalor();
	printf("Ahora el valor de contador es de: %d\n",contador);
	return 0;
}
void imprimevalor(){
	int contador = 5;
	printf("El valor de contador es: %d\n",contador);
}

