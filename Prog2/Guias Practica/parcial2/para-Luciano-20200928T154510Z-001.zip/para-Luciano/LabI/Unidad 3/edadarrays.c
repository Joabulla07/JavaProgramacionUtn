#include <stdio.h>

int main(int argc, char *argv[]) {
	int i = 0,n;
	
	printf("Dame el tamanio\n");
	/* pido tamanio */ 
	scanf("%d",&n);
	/* leo tamanio */
	int edad[n];
	/* declaro arreglo */ 
	for (i = 0; i < n;i++){ /* i=0 n=5, 0 es menor que 5? si, almaceno dato en edad[0], i = 1, 1 < 5 ? si, almaceno dato en edad[1],etc*/
		printf("Dame datos\n",i+1);
		scanf("%d",&edad[i]);
	}
	 printf("Los valores del arreglo son:\n"); /* printf para mostrar cada edad[i] */
	for (i = 0; i < n;i++){ /* Para i = 0, 0 < 5, i +1, i = 0, 0 < 5? muestro edad[0], i+1, para i = 1, 1 < 5?, muestro edad[1], i++,etc*/
		printf("%d\n",edad[i]);
	}
	return 0;
}

