#include <stdio.h>
#include <curses.h>
int factorial(int n);
int main(int argc, char *argv[]){

    int i=1,n;
    printf("Ingrese el factorial: \n");
    scanf("%d",&n);
    printf("El factorial del numero ingresado es: %d\n",factorial(n));
    return 0;
}
int factorial(int n){
    int fact = 1,i;
    for (i = 1;i <= n; i++){
        fact = fact * i;
    }
    
    return fact;
}
