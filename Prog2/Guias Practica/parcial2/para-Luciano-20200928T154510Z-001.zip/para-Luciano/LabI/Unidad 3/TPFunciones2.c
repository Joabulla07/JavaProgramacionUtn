#include <stdio.h>
#include <curses.h>
int producto1(int a, int b, int n, int i);
int producto2(int a, int acum);
int main(){
    int n,a,b,acum,acum2=0;
    int i=0;
    do{
    printf("Ingrese la cantidad de numeros a multiplicar: ");
    scanf("%d",&n);
    }while(n<=1);
    while (i < n){
        printf("\n Ingrese un numero: \n");
        scanf("%d",&a);
        if (i == 0){
            printf("Ingrese un segundo numero: \n");
            scanf("%d",&b);
            acum = producto1(a,b,n,i);
            printf("El resulado entre %d y %d es: %d",a,b,acum);
        }else{
            acum2 += producto2(a,acum);
            printf("El resultado entre el anterior producto y %d es: %d\n",a,acum2);
        }
        i++;
    }
    return 0;
}
int producto1(int a, int b, int n, int i){
    int acum =0;
 if (i == 0){
     acum = a*b;
     return acum;
 } 
 }
int producto2(int a,int acum){

    return (acum*=a);
}
