#include <stdio.h>
int sumar(int a, int b);
void saludo(){
	printf("Este programa se dedica a sumar 2 valores ingresados.\n\n\n\n");
	printf("Ingrese 2 valores enteros, cada uno seguido por un espacio.\n");
}
void suma(){
	printf("La suma de los valores ingresados es de ");
}
int main(int argc, char *argv[]) {
	int num1,num2;
	saludo();
	scanf("%d %d",&num1,&num2);
	suma();
	printf("%d",sumar(num1,num2));

	return 0;
}
int sumar(int a, int b){
	int sumaa = a + b;
	return sumaa;
}
