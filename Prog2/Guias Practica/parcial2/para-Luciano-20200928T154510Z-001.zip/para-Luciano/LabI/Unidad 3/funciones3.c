#include <stdio.h>
/* Escribir un programa que indique el numero mas grande y mas pequenio ingresado y el promedio de n numeros.
El valor N se solicitara al principio del programa y los numeros seran introducidos por el usuario.*/ 
float min(float a, float b);
float max(float a, float b);
float avg(float a, float b);

int main(int argc, char *argv[]){
	int n;
	float num1,num2,acum=0;
	printf("Ingrese el valor de n (Las veces que el programa repetira un ciclo de promedio de 2 numeros + resultado anterior.)\n");
	scanf("%d",&n);
	for (int i = 0;i < n;i++){
		printf("Ingrese un numero.\n");
		scanf("%f",&num1);
		printf("Ingrese un segundo numero.\n");
		scanf("%f",&num2);
		printf("El menor de los numeros ingresados es %f\n",min(num1,num2));
		printf("El mayor de los numeros ingresados es %f\n",max(num1,num2));
		if (i == 0){
			acum = avg(num1,num2) / 2;
			printf("El promedio de los numeros ingresados es de: %f",acum);
		}else{
			acum = avg(num1,num2) / 2;
			printf("El promedio de los numeros ingresados mas el promedio anterior es: %f",acum);
		}
		return 0;
	}
}
float min(float a, float b){
	float menor;
		if (a < b){
			menor = a;
			return menor;
		}else{
			menor = b;
			return menor;
		}
}
float max(float a, float b){
	float mayor;
	if (a > b){
		mayor = a;
		return mayor;
	}else{
		mayor = b;
		return mayor;
	}
}
float avg(float a, float b){
	float suma = 0;
	suma = suma + a + b;
	return suma;
}
