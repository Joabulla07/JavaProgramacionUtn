#include <stdio.h>
#include <curses.h>
int sacarpromedio(int acum, int n);
int esmayor(int a, int mayor);
int esmenor(int a, int menor);
int main(int argc, char *argv[]){
    int n,a,c=0,i=0,acum=0,promedio,mayor,menor;
    do{
        if (c == 0){
    printf("Ingrese la cantidad de numeros que seran ingresados.\n");
       c++;
        }
    scanf("%d",&n);
    if (n <= 1){
        printf("El numero que ingreso es menor o igual a 1.\nIngrese un numero mayor a 1: \n");
    }
    }while(n <= 1);
    while (i < n){
        printf("Ingrese un numero: \n");
        scanf("%d",&a);
        acum+=a;
        if (i == 0){
            mayor = a;
            menor = a;
        }
        mayor = esmayor(a,mayor);
        menor = esmenor(a,menor);
    i++;
    }
    promedio = sacarpromedio(acum,n);
    printf("El promedio de los numeros ingresados es: %d\n",promedio);
    printf("El numero mas chico ingresado fue: %d y el mas grande fue: %d\n",menor,mayor);
    return 0;
}
int sacarpromedio(int acum, int n){
    int promedio;
    promedio = acum / n;
    return promedio;
}
int esmayor(int a, int mayor){
    int aux;
    if (a > mayor){
        aux = a;
        return aux;
    }else{
        return mayor;
    }
}
int esmenor(int a, int menor){
    int aux;
    if (a < menor){
        aux = a;
        return aux;
    }else{
        return menor;
    }
}
