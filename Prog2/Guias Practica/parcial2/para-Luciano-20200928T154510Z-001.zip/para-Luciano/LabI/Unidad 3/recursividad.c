
#include <stdio.h>
unsigned long long int factorial (unsigned long long int numero);
int main(int argc, char *argv[]) {
	int numero;
	printf("ingrese un numero: \n");
	scanf("%d",&numero);
	
	for (int i = 0;i <= numero;i++){
		printf("El factorial del numero %d es de: %llu\n",i,factorial(i));
	}
	return 0;
}
unsigned long long int factorial(unsigned long long int numero){
	if (numero <= 1){
		return 1;
	}else{
		return (numero * factorial(numero-1));
	}
	
}

