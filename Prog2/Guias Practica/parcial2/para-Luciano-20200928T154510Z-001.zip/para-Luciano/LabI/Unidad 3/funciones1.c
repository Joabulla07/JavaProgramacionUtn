#include <stdio.h>

/* Ingresar 10 numeros por pantalla y calcular la suma de los mismos. 
Mostrar por pantalla los numeros ingresados y el resultado obtenido.*/ 
int sumadenumeros(int a);
int main(int argc, char *argv[])
{
	int num,sumatotal;
	sumatotal = 0;
	for (int i = 0;i<10;i++)
	{
		printf("Ingrese un numero.\n\n");
		scanf("%d",&num);
		printf("El numero ingresado fue: %d\n\n",num);
		sumatotal = sumatotal + sumadenumeros(num);
		printf("La suma de los numeros ingresados es de: %d\n\n",sumatotal);
	}
	
}
int sumadenumeros(int a)
{
	int sumatotal=0;
	sumatotal+=a;
	return sumatotal;
}


