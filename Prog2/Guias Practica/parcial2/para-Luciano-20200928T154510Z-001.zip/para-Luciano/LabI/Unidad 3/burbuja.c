#include <stdio.h>
#define MAX 1000
int main(int argc, char *argv[]) {
	
	int cn,n,q,w,aux,n[MAX];
	
	printf("Dimension del vector: ");
	scanf("%d",&cn);
	
	for (q=0;q<cn;q++){
		printf("Ingrese el elemento: ");
		scanf("%d",n[q]);
	}
	for (q = 1; q < cn;q++){
		for (w=0;j<cn-q;w++){
			if (n[w]>n[w+q]){
				aux = n[w+q];
				n[w+1] = n[w];
				n[w] = aux;
			}		
		}
	}
	for (q=0;q<cn;q++){
		printf("\n%d",n[q]);
		
	}
		return 0;
}

