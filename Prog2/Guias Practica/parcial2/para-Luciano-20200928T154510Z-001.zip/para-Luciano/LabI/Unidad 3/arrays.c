#include <stdio.h>
#include <conio.h>
#define ULT 9
#define MAX 1000	
int main(int argc, char *argv[]) {
	/* Utilizacion de arreglos*/
	int lista[ULT]={0,4,78,5,32,9,77,1,23};
	int i,j,k,l,m,cont,a;
	int cn,q,w,aux,n[MAX];
	int busqueda;
	int lista1[ULT];
	int lista2[ULT];
	cont = 0;
	
	for (j = 0;j<ULT;j++){ /* Obtencion de datos para cada posicion del array LISTA1 */ 
		printf("Ingresar el elemento %d para el array LISTA1\n",j);
		scanf("%d",&lista1[j]);
		printf("Posicion del arreglo LISTA1: %d\n,>>Valor guardado en dicha posicion: %d\n\n<<",j,lista1[j]);
		
	}
	for (i = 0;i<ULT;i++){ /* Como mostrar por pantalla los elementos de un array. LISTA */ 
		printf("Posicion del arreglo LISTA %d\n: Valor guardado en dicha posicion %d\n\n",i,lista[i]);
		
	}
	for (k = 0; k < ULT;k++){ /* Comparacion de cual es el menor elemento entre los arreglos LISTA1 Y LISTA, el menor de estos es asignado a
		la misma posicion en un arreglo separado llamado lISTA2*/
		if (lista[k]<lista1[k]){
			lista2[k] = lista[k];
		}else if (lista1[k]<lista[k]){
			lista2[k] = lista1[k];
		}else if (lista[k] == lista1[k]){
			lista2[k] = lista[k];
		}
	}
	for (l = 9;l<9;l--){ /* Muestra por pantalla los elementos obtenidos previamente de LISTA2 al revez, de posicion 8 a posicion 0*/ 
		printf("Posicion del arreglo LISTA2 %d\n\n Valor guardado en dicha posicion: %d\n",l,lista2[l]);
	}
	do{
		printf("Ingresa por teclado la posicion que quiere revisar del arreglo LISTA2\n");
		scanf("%d",&l);
		
		if (l >= 0 && l < ULT){
			printf("El valor de la posicion ingresada es: %d\n",lista2[l]);
		}else{
			printf("Datos ingresados INCORRECTOS, por favor, vuelva a ingresar otro dato, tenga en cuenta que la lista va del 0 al 8.\n");
		}
	}while(l <= 0);
	printf("Ingrese un valor para revisar si esta en la lista.\n");
	scanf("%d",&a);
	for (m = 0;m<ULT;m++){
		if (lista2[m] == a){
			cont++;
			printf("El valor ingresado: %d fue encontrado %d veces en el array, en la posicion %d\n\n\n\n",a,cont,l);
		}
	}
	printf("Dimension del vector: ");
	scanf("%d",&cn);
	
	for (q=0;q<cn;q++){
		printf("Ingrese el elemento: ");
		scanf("%d",&n[q]);
	}
	for (q = 1; q < cn;q++){
		for (w=0;j<cn-q;w++){
			if (n[w]>n[w+q]){
				aux = n[w+q];
				n[w+1] = n[w];
				n[w] = aux;
			}		
		}
	}
	for (q=0;q<cn;q++){
		printf("\n%d",n[q]);
		
	}
	printf("Ingrese un numero para saber si esta en LISTA2.\n");
	scanf("%d",&busqueda);
	printf("El dato ingresado: %d se encuentra en el arreglo.\n",busquedaBinaria(lista2[ULT],n,busqueda));
	return 0;
}

int busquedaBinaria(){
	izq = 0;
	
	
	return -1;
/* 
Ejercicio 1: Indicar si es posible ordenar un arreglo con elementos repetidos usando el metodo de la burbuja.
Ejercicio 2: Modificar el metodo de ordenamiento de la burbuja, para ordenar de mayor a menor.
Ejercicio 3: Verificar si la busqueda binaria funciona para un arreglo ordenado con elementos repetidos, si es asi, modificar el algoritmo
de tal manera que me indique cuantas veces aparece el elemento repetido.
Ejercicio 4: operacion elemimacion, realizar los programas de eliminacion que se adecuen a cada una de las situaciones planteadas. */ 
