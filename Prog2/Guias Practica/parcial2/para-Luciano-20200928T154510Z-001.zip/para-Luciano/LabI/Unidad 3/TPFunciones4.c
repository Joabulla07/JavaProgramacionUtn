#include <stdio.h>
#include <curses.h>

int fibonacci(int n);
int main(int argc, char *argv[]){
    int i; /* Declaracion de 2 variables, i para controlar las posiciones de los numeros de fibonacci, 
    en esta caso desde 1 hasta 15.*/
    int j; /* J sera la variable que se pasara a la funcion para controlar cuantas veces hago el traspaso de variables.*/
    for (i = 1; i <= 15;i++){ /* Bucle que se encarga de mostrar desde el numero 1 haasta el numero 15 lo que me retorne
    la funcion. */
        printf("%d ",fibonacci(j));
        j++; /* j = n en fibonacci. */
    }
    
    return 0;
}
int fibonacci(int n){
    int i; /* contador encargado de contar todos los casos en los cuales n != 1 o 2 */
    int f1 = 0; /* condicion de fibonacci numero 1, F1 = 0*/
    int f2 = 1; /* condicion de fibonacci numero 2, F2 = 1 */
    int fi; /* Variable encargada de recorrer todos los numeros F3 hasta F15. */
    if (n == 0){
        return 0;
    }
    if (n == 1){
        return 1;
    }
    for (i = 2;i<=n;i++){ /* Bucle que controla que si i es menor o igual a n, si es verdadero, hace el traspaso
    de variables Fi = 0 + 1, F1 = 1, F2 = 1 TANTAS veces como N con los nuevos valores.*/
        fi = f1 + f2;
        f1 = f2;
        f2 = fi;
    }
    return fi;

}
