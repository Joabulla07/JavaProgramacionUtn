#incldue <stdio.h>
#include <conio.h>
#include <stdbool.h>
#include <stdlib.h>

int main(){
	int numero;
	printf("Ingrese un numero: ");
	scanf("%d",&numero);
	printf("El numero ingresado es de: %d",numero);
}
