#include <stdio.h>
#include <conio.h>

int main()
{
	
	char c1;
	char c2;
	
	
	printf("Ingrese 2 caracteres juntos sin espacios (ej: cd).\n");
	scanf("%c",&c1);
	scanf("%c",&c2);
	
	
	if ((c1 != 'a' && c2 != 'a') && ( c1 != c2))
	{
		
		printf("Mauricio");
		
	}
	else 
		printf("Benitez");
	
	
	return 0;
}
