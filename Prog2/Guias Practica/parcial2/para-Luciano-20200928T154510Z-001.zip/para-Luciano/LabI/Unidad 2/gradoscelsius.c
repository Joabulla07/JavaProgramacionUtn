#include <stdio.h>
float gfahr(float celsius);
int main(int argc, char *argv[]) {
	int mayor,pasos;
	float celsius;
	
	mayor = 300;
	pasos = 10;
	celsius = 0;
	printf("Fahrenheit      Celsius\n");
	while (celsius <= mayor){
		printf ("%3.0f\t\t%6.1f\n",gfahr(celsius),celsius);
		celsius = celsius + pasos;
	}
	
	return 0;
	
}
float gfahr(float celsius){
	float grados;
	grados = (9 * celsius / 5) + 32.0;
	return grados;
}

