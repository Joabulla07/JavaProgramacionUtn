#include <stdio.h>
#include <conio.h>

int main (){
	int a,b,c,d,e,acum,prom,cont,x,m,acum2;
	x = 1;
	m = 0;
	cont = 0;
	while (x == 1){
		printf("ingrese 5 numeros a continuacion:\n");
		scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
		printf("los numeros ingresados fueron: %d,%d,%d,%d,%d\n",a,b,c,d,e);
		acum = a+b+c+d+e;
		prom = acum / 5;
		printf("la suma total de los numeros ingresados es de: %d\nel promedio de los numeros ingresados es de: %d\n",acum,prom);
		if (a >= 15){m++;}else cont++;
		if (b >= 15){m++;}else cont++;
		if (c >= 15){m++;}else cont++;
		if (d >= 15){m++;}else cont++;
		if (e >= 15){m++;}else cont++;

		printf("La cantidad de numeros mayores a 15 es de: %d\n",m);
		printf("La cantidad de numeros menores a 15 es de: %d\n",cont);
		printf("Quiere que el programa se repita?\n1:Si\n2:No\n");
		scanf("%d",&x);
	}
}


