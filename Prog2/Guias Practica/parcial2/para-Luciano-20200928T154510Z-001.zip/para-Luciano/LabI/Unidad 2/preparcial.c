#include <stdio.h>
#include <conio.h>
/* Ejercicio N� 4:
Escriba un programa que reciba cuatro calificaciones de un estudiante y devuelva el promedio y la m�xima y la m�nima calificaci�n.*/ 
int main(){
	float cal1,cal2,cal3,cal4,promedio,maxcal,mincal;
	int bandera = 1,acum = 0;
	printf("Ingrese las calificaciones seguidas de un espacio.\n");
	scanf("%f %f %f %f",&cal1,&cal2,&cal3,&cal4);
	
	do{
		acum = cal1 + cal2 + cal3 + cal4;
		promedio = acum / 4;
		printf("El promedio total de las calificaciones es de: %.2f\n",promedio);
		if ((cal1 < cal2) && (cal2 < cal3) && (cal3 < cal4)){
			mincal = cal1;
			maxcal = cal4;
		}else if ((cal2 < cal1) && (cal1 < cal4) && (cal4 < cal3)){
			mincal = cal2;
			maxcal = cal3;
		}else if ((cal3 < cal1) && (cal1 < cal4) && (cal4 < cal2)){
			mincal = cal3;
			maxcal = cal2;
		}else if((cal4 < cal2) && (cal2 < cal3) && (cal3 < cal1)){
			mincal = cal4; 
			maxcal = cal1;
		}
		
		printf("La calificacion mas chica entre las 4 calificaciones ingresadas es: %.2f\n",mincal);
		printf("La calificacion mas grande entre las 4 calificaciones ingresadas es: %.2f\n",maxcal);
		
		
		printf("Desea seguir usando el programa? Ingrese su eleccion.\n");
		printf("\n");
		printf("1.Si");
		printf("\n");
		printf("2.No\n");
		scanf("%d",&bandera);
	}while (bandera == 1);
	return 0;
}
