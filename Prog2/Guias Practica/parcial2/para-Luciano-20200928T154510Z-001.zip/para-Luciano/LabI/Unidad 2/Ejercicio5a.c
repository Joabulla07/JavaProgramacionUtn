#include <stdio.h>
#include <conio.h>

int main(){
int a;
int triplo;

printf("Ingrese el valor para A\n");
scanf("%d",&a);
if ( ( a > 0 ) && ( a % 2 == 0 ) ) {    // uso el modulo (%) para saber si es divisible por 2, si fuera divisible por 2 deberia dar 0 en la 2da condicion.
	triplo = a * 3;
	printf("El triplo del numero ingresado es: %d\n",triplo);
}
	else
	printf("No se puede realizar el calculo ya que el valor ingresado para A no es divisible por 2.\n");

	return 0;
}
