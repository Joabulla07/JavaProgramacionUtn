#include <stdio.h>

/*Normalmente, no se conoce con exactitud cuantos elementos de datos se procesar�n antes de comenzar
su ejecuci�n. Esto se produce bien porque hay muchos datos a contar normalmente o porque el n�mero
de datos a procesar depende de c�mo prosigue el proceso de c�lculo.
Un medio para manejar esta situaci�n es instruir al usuario a introducir un �nico dato definido y
especificado denominado valor centinela como �ltimo dato. La condici�n del bucle comprueba cada
dato y termina cuando se lee el valor centinela. El valor centinela se debe seleccionar con mucho cuidado
y debe ser un valor que no pueda producirse como dato. En realidad el centinela es un valor que sirve
para terminar el proceso del bucle.
En el siguiente fragmento de c�digo hay un bucle con centinela; se introducen notas mientras que
�sta sea distinta de centinela. */
int main() {
	const int centinela = -1;
	int nota,cuenta,suma;
	printf ("Introduzca primera nota:");
	scanf ("%d", &nota);
	while (nota != centinela)
	{
		cuenta++;
		suma += nota;
		printf ("Introduzca la siquiente nota: ");
		scanf ("%d", &nota); 
	}
	return 0;
}

