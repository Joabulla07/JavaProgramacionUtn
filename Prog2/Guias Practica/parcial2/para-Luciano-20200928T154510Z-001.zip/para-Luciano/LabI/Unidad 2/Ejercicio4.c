#include <stdio.h>
#include <conio.h>
#define i 10
#define j 5
#define k -2
#define c1 w
#define ?


int main(){

// a) (i < 10) && (j == 5) No es cierta ya que el valor de I no es menor a 10, es 10.
// b) (i <= 10) && (j == 5) Es cierta ya que al tener un mayor o igual ahora si se cumple la condicion.
// c) ! (k = 3) es verdadero ya que el operador !nor hace que k = 3 siendo falso termine verdadero.
// d) (k != 3) || ( c1 == 'w') es cierta ya que k es distinto de 3 y c1 esta asignado al caracter 'w'.




}
