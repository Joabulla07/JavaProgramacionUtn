#include <stdio.h>
#include <conio.h>
#define limi 100
#define lime 200

int main(){

	int a;
	
	
	printf("Ingrese un valor el cual quiera saber si esta entre los limites establecidos por este programa.\n");
	scanf("%d",&a);
	if ( (limi <= a ) && ( a <= lime ) )
	{
		printf("El numero ingresado esta esta comprendido entre 100 y 200, los cuales son los limites interior y exterior respectivamente.");
	}
	else 
		 printf("El numero ingresado no esta comprendido entre los limites establecidos por este programa.\n");
	
	return 0;
}

