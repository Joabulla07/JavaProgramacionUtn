#include <stdio.h>
#include <conio.h>

/* Se ingresa por teclado la cantidad de agua caida, en mílimetros día a día durante un mes. Se pide determinar el día de mayor lluvia, el de menor y el promedio.*/
int main(){
	printf("Este programa esta dedicado para Micaela Nisoria, te quiero bebe<3\n");
	int mmdia,mmmes,diamayor,diamenor,promedio,dia,checker;
	dia = 1;
	checker = 3;
	while (checker != 1 || checker != 2){
		printf("Porfavor, ingrese con un 1 si el corriente mes tiene 30 dias, sino con un 2 si el corriente mes tiene 31 dias.\n");
		scanf("%d",&checker);
		if (checker == 2){
			while (dia <= 31){
				printf("Ingrese la cantidad de lluvia que llovio en el dia.\n");
				scanf("%d",&mmdia);
				if (dia == 1){
					diamayor = mmdia;
					diamenor = mmdia;
				}else if (mmdia > diamayor){
					diamayor = mmdia;
				}else if (mmdia < diamenor){
					diamenor = mmdia;}
				mmmes = mmmes + mmdia;
				promedio = mmmes / 31;
				printf("Hasta el dia de la fecha: %d la cantidad de menor lluvia en un dia fue de:%d\nLa cantidad de mayor lluvia en un dia fue de:%d\n",dia,diamenor,diamayor);
				printf("\n");
				printf("El total de lluvia en el mes es de:%d\n",mmmes);
				printf("\n");
				printf("El promedio de mm en todo el mes fue de: %d\n",promedio);}
		}else if (checker == 1){
			while (dia <= 30){
				printf("Ingrese la cantidad de lluvia que llovio:\n");
				scanf("%d",&mmdia);
				if (dia == 1){
					diamayor = mmdia;
					diamenor = mmdia;
				}else if (diamayor < mmdia){
					diamayor = mmdia;
				}else if (diamenor > mmdia){
					diamenor = mmdia;}
				mmmes = mmmes + mmdia;
				promedio = mmmes / 30;
				printf("Hasta el dia de la fecha: %d la cantidad de menor lluvia en un dia fue de: %d\nLa cantidad de mayor lluvia en un dia fue de:%d\n",dia,diamenor,diamayor);
				printf("\n");
				printf("El total de lluvia en el mes es de:%d\n",mmmes);
				printf("\n");
				printf("El promedio de mm en todo el mes fue de:%d\n",promedio);
			}
		}else printf("Numero incorrecto, por favor ingrese 1 para actuar en un plan de 30 dias o 2 para actuar en un plan de 31 dias.\n");
	}
}
	
		
