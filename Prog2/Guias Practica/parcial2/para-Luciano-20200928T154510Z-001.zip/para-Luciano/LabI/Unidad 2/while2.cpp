#include <stdio.h>
#include <conio.h>
#include <stdbool.h>

int main(void){
	int sum1,sum2,bandera,acumulador;
	printf("Ingrese 2 valores a multiplicar.\n");
	scanf("%d %d",&sum1,&sum2);
	if (sum1 && sum2){
		acumulador = 0;
		if (sum2)
		{
			bandera = 1;
			while (bandera <= sum1)
			{
				acumulador += sum2;
				bandera++;
			}
		 
		}
		printf("%d multiplicado por %d es igual a: %d\n",sum1,sum2,acumulador);
	}else printf("Los numeros ingresados deben ser mayores o iguales que 0.\n");
	
}
