#include <stdio.h>
float celsius(float fahre);
int main(int argc, char *argv[]) {
	int upper,step;
	float fahr;
	upper = 300;
	step = 20;
	fahr = 0;
	printf("Celsius      Fahrenheit\n");
	while (fahr <= upper){
		
		printf ("%3.0f\t\t%6.1f\n",fahr,celsius(fahr));
		fahr = fahr + step;
	}
	return 0;
}
float celsius(float fahre){
	float grades;
	grades = 5 * (fahre - 32.0) / 9;
	return grades;
}
