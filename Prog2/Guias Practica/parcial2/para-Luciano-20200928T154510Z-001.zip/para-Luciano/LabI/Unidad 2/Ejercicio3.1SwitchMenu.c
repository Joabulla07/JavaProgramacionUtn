#include <stdio.h>
#include <conio.h>

int main(){	int opcion;
	
	printf("             ............                  .............\n");
	printf(".........................Sistema de pedidos.........................\n");
	printf("\n");
	printf("\n");
	printf("        1 - Bebidas\n");
	printf("        2 - Comidas\n");
	printf("        3 - Postres\n");
	printf("        4 - Salir\n");
	printf("\n");
	printf("\n");
	printf(".......................................................................\n");
	printf("Elija una opcion...\n");
	printf("***********************************************************************\n");
	scanf("%d",&opcion);
	
	switch (opcion){
	case 1 : /* Bebidas */
	printf("Usted eligio la opcion numero 1, Bebidas.\n");
	break;
	
	case 2 :/* Comidas */
	printf("Usted eligio la opcion numero 2, Comidas.\n");
	break;
	
	
	case 3 : /* Postres */
	printf("Usted eligio la opcion numero 3, Postres.");
	break;
	
	
	case 4 : /* Salir */
	printf("Esta seguro que quiere salir del menu? Y/N \n");
	break;
	
	default: /* Error */
	printf("Usted ha ingresado una opcion valida, por favor, ingrese un valor entero entre el 1-4.\n");
	break;
	
	return 0;
	
		}
	
	
}
