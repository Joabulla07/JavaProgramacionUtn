#include <stdio.h>
#include <conio.h>
/* Mostrar por pantalla los numeros pares (de mayor a menor) comprendidos entre 50 y 20. Indicar la cantidad de numeros hallados. */
int main(){
	int cont,acum;
	cont = 50;
	acum = 0;
	while (cont % 2 == 0){
		if (cont >= 20 && cont <= 50 && acum >= 0 && acum <= 50){
			acum = acum+1;
			cont = cont - 2;
			printf("Numeros: %d\t",cont);
			printf("Numeros hallados: %d\n",acum);
		}
	}
	return 0;
}
