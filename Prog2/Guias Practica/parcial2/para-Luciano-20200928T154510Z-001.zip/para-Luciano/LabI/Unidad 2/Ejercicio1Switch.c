#include <stdio.h>
#include <conio.h>

int main() {
	float precio_libro, precio_neto;
	float descuento;
	int codigo;
	printf("Introduzca el precio del libro:\n");
	scanf("%f",&precio_libro);
	printf("Introduzca el codigo del ciente:5\n");
	scanf("%d",&codigo);
	
	switch (codigo) {
	case 1: /* Clientes registrados */
		descuento = 0.10;
		precio_neto = precio_libro - (precio_libro * descuento);
		break;
		
	case 2:/* Mayoristas */ 
		descuento = 0.15;
		precio_neto = precio_libro - (precio_libro * descuento);
		break;
		
	case 3: /* Empleados de la empresa */
		descuento = 0.17;
		precio_neto = precio_libro - (precio_libro * descuento);
		break;
		
	default: /* Nuevos clientes */ 
		descuento = 0.05;
		precio_neto = precio_libro - (precio_libro * descuento);
		break;
	} 
	
	
	printf("El precio neto del libro es %.2f\n", precio_neto);
	
	return 0;
	
}
