#include <stdio.h>
#include <conio.h>

int main(){
/* Complete el programa para que se imprima en pantalla la opcion seleccionada por lel usuario y que muestre un mensaje de error si el numero ingresado no esta entre 1 y 4*/ 
	int opcion;
	
	printf("             ............                  .............\n");
	printf(".........................Sistema de puteadas.........................\n");
	printf("\n");
	printf("\n");
	printf("        1 - Maurizio45 dijo una boludez denuevo\n");
	printf("        2 - Bubu se fue a tomar birra un miercoles otra vez\n");
	printf("        3 - Daaarkmaster no esta aprendiendo  c\n");
	printf("        4 - Estan hablando de gente que odian denuevo\n");
	printf("\n");
	printf("\n");
	printf(".......................................................................\n");
	printf("Elija una opcion por la cual putear...\n");
	printf("***********************************************************************\n");
	scanf("%d",&opcion);
	
	switch (opcion){
	case 1 : /* Bebidas */
	printf("Usted eligio la opcion numero 1, Maurizio45.\n");
	break;
	
	case 2 :/* Comidas */
	printf("Usted eligio la opcion numero 2, Comidas.\n");
	break;
	
	
	case 3 : /* Postres */
	printf("Usted eligio la opcion numero 3, Postres.");
	break;
	
	
	case 4 : /* Salir */
	printf("Esta seguro que quiere salir del menu? Y/N \n");
	break;
	
	default: /* Error */
	printf("Usted ha ingresado una opcion valida, por favor, ingrese un valor entero entre el 1-4.\n");
	break;
	
	return 0;
	
		}
	
	
}
