#include <stdio.h>
#include <conio.h>
int main() {
	int suma,resta,multi,divison,a,b,x;
	int valor;
	x = 1;
	while (x == 1){
		printf("Ingrese dos valores\n");
		scanf("%d %d",&a,&b);
		if (a && b){
			
			
			printf("1- Suma\n");
			printf("2- Resta\n");
			printf("3- Multiplicacion\n");
			printf("4- Division\n");
			
			printf("Ingrese la opearcion que quiere hacer\n");
			
			scanf("%d",&valor);
			
			
			switch (valor) {
			case 1:
				if (a > 0 && b > 0) {
					suma = a + b;
					printf("la suma de los valores ingresados es: %d\n",suma);
				}else{
					printf("Los valores ingresados son menores o iguales a 0, por favor ingrese valores mayores a 0.\n");
				}
				break;
			case 2:
				
				if ( a >= b && a > 0 && b > 0){
					resta = a - b;
					printf("La resta de los valores ingresados es: %d\n",resta);
				}else{
					printf("Los valores ingresados son invalidos, por favor asegurese que el primer valor sea mayor al segundo y que estos sean mayores que 0 e intente nuevamente.");
				}
				break;
			case 3:
				
				if (a > 0 && b > 0) {
					multi = a * b;
					printf("El valor del producto es: %d\n",multi);
				}else{
					printf("Los valores ingresados son menores o iguales a 0, porfavor ingrese valores mayores a 0.\n");
				}
				break;
			case 4:
				
				if (a > 0 && b > 0) {
					
					divison = a / b;
					if (a / b && a % b == 0){
						printf("La division de los valores ingresados es: %d\n",divison);
					}else{
						printf("Error: La division no es exacta o el primer numero no fue divido por el segundo.\n");
					}
				}else{
					printf("Error: Los valores ingresados son menores o iguales a 0.\n");
				}
				break;
			default:
				printf("El valor ingresado es erroneo, porfavor ingrese un valor del 1 al 4.");
				
				
			}
		}else{
			printf("Los valores ingresados son menores o iguales a 0, porfavor ingrese valores mayores a 0.\n");
		}
		
		printf("Quiere seguir ejecutando el programa?\n1:Si\n2:No\n");
		scanf("%d",&x);
	}
	return 0;
}

