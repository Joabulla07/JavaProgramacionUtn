#include <stdio.h>
#include <conio.h>
#define PULCM 2.54
#define LIBKG 0.453592

/* Usando sentencia switch,hacer un programa en C que convierta cent�metros a pulgadas y libras a kilogramos. El proceso se puede repetir varias veces hasta que el usuario seleccione la opci�n terminar. 
 1 pul = 2,54cm
 1 lib = 0,453592 kg;
*/ 
int main(){
	int bandera = 1,opcion;
	float kg,cm,lib,pul;
	
	printf("Conversor de Pulgadas/cm  y Libras/kg\n");
	printf("\n");
	do{
		
		printf("Ingrese su opcion:\n");
		printf("\n");
		printf("1. CM a PULGADAS\n");
		printf("\n");
		printf("2. LIBRAS A KG\n");
		scanf("%d",&opcion);
		switch (opcion){
			
		case 1: printf("Ingrese el valor de cms a convertir a pulgadas.\n");
		scanf("%f",&cm);
		pul = cm / PULCM;
		printf("%.2f centimetros son %.2f pulgadas.\n",cm,pul);
		break;
		case 2: printf("Ingrese el valor de kg a convertir a libras.\n");
		scanf("%f",&kg);
		lib = kg / LIBKG;
		printf("%.2f kilogramos son %.2f libras.\n",kg,lib);
		break;
		default: printf("ERROR: Opcion incorrecta.\n");
		printf("\n");
		}
	}while (bandera == 1);
}
