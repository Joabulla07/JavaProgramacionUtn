#include <stdio.h>
#include <conio.h>

int main ()
{
	int a,b,c;
	
	printf("Ingrese los valores para A, B, C seguidos de un espacio (Ej: 1 2 3 (enter))\n");
	scanf("%d %d %d",&a,&b,&c);
	printf("Usted ingreso: %d , %d , %d\n",a,b,c);
	
	if ((a == b) && (b == c) && (c == a ))
	{
		printf("Los 3 valores ingresados son iguales entre si.\n");
	}
	else
		printf("Al menos uno de los valores ingresados es desigual con respecto a los demas, por favor, ingrese 3 valores iguales entre si.\n");
	return 0;
}

