#include <stdio.h>
#include <conio.h>
#include <math.h>
#define M_PI 3.14159265358979323846
/*Calcular la superficie de un círculo. La operación se realizará una vez comprobado que los valores ingresados sean correctos.*/

int main(){
	double r,superficie;
	int bandera;
	printf("Ingrese el radio del circulo a calcular: \n");
	scanf("%lf",&r);
	bandera = 1;
	while (bandera == 1){
		if (r > 0){
			superficie = M_PI * (pow(r,2));
			printf("El valor de la superficie del circulo es de: %.3f\n",superficie);
		}
		printf("A continuacion,Ingrese:\n1:Para hacer otro calculo\n2(o cualquier numero.)Para terminar el programa.\n");
		scanf("%d",&bandera);
	}
	return 0 ;
}
