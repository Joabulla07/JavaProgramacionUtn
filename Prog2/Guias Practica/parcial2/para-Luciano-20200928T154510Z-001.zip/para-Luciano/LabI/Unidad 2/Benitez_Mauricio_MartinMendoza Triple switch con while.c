#include <stdio.h>

int main(){
	int sexo,edad,edad2,educacion;
	int cont;
	cont = 0;
	while (cont < 5){
		
		printf("Ingrsee su sexo:\n1:Masculino\n2:Femenino\n3:Indefinido\n");
		scanf("%d",&sexo);
		printf("Ingrese su edad: \n");
		scanf("%d",&edad);
		if (edad > 21){
			edad2 = 1;
		}else edad2 = 2;
		printf("Ingrese sus estudios: \n1:Primarios\n2:Secundarios\n3:Superiores No Universitarios.\n4:Universitarios.\n5:Otros.\n");
		scanf("%d",&educacion);
		switch (sexo){
		case 1: printf("Usted es un hombre.\n");break;
		case 2: printf("Usted es una mujer.\n");break;
		case 3: printf("Usted es de sexo indefinido.\n");break;
		default: printf("Usted ingreso un numero no valido.\n");
		}
		switch (edad2){
		case 1: printf("Usted es mayor a 21 a�os\n");break;
		case 2: printf("Usted es menor a 21 a�os");break;
		}
		switch (educacion) {
		case 1: printf("Sus estudios son: Primarios.\n");break;
		case 2: printf("Sus estudios son: Secundarios.\n");break;
		case 3: printf("Sus estudios son: Superiores no universitarios.\n");break;
		case 4: printf("Sus estudios son: Universitarios\n");break;
		case 5: printf("Sus estudios son Otros.\n");
		}
		
		
		cont++;
	}
	return 0;
}

