#include <stdio.h>
#include <conio.h>

int main(int argc, char *argv[]) {
	
	int A[5] [2]= {
		0,1
			,2,3
			,4,5
			,6,7,
			8,9
	};
	int B[5] [2];
	int C[5] [2];
	int i,j,bandera=1,cont,filaC,columnaC,num,acum,suma;
	
	for (i = 0;i<=5;i++){ /* Mosrar contenido de la matriz A*/
		for (j = 0;j<2;j++){
			printf("Matriz A [%d] [%d] = ",i,j);
			printf("%d\t\n",A[i][j]);
		}
	}
	
	for (i = 0;i<=5;i++){ /* Obtencion y asignado de datos para todas las filas y columnas de la matriz B, Muestra de la matriz B */
		for (j = 0;j<2;j++){
			printf("Ingrese un valor para [%d] [%d].\n",i,j);
			scanf("%d",&B[i][j]);
			printf("Matriz B [%d] [%d] = ",i,j);
			printf("%d\t\n\n\n",B[i][j]);
		}
	}
	for (i = 0;i<=5;i++){ /* Obtencion de datos de la matriz C por medio de suma entre matriz A y matriz B */
		for (j = 0;j<2;j++){
			C[i][j] = A[i][j] + B[i][j];
			printf("Matriz C [%d] [%d] = ",i,j);
			printf("%d\t\n",C[i][j]);
		}
	}
	do {
		printf("Ingrese una fila de la matriz C\n");
		scanf("%d",&filaC);
		printf("Ingrese una columna de la matriz C\n");
		scanf("%d",&columnaC);
		if ((filaC <= 5 && filaC >= 0) && (columnaC >= 0 && columnaC <= 1)){
			printf("Matriz C [%d] [%d] = %d \n",filaC,columnaC,C[filaC][columnaC]);
		}else{
			printf("DATOS INGRESADOS INCORRECTOS.\n");
		}
		printf("Desea ingresar otras corrdenadas?\n1.Si\n2.No\n");
		scanf("%d",&bandera);
	}while(bandera==1);
	
	printf("Ingrese un valor para buscar en toda la matriz.\n");
	scanf("%d",&num);
	cont = 0;

	for (i = 0;i<=5;i++){ /* Buscar un valor en toda la matriz y contar cuantas veces se repite dicho numero en la matriz.*/
		for (j = 0;j<=1;j++){
			if (C[i][j] == num){
				cont++;
				printf("El valor ingreasdo: %d fue encontrado en matriz C [%d] [%d] \n",num,i,j);
			}
		}
	}
	if (cont == 1){ 
	printf("El valor %d fue encontrado %d vez.\n",num,cont);
	}else{
		printf("El valor %d fue encontrado %d veces.\n",num,cont);
	}
     /* Mostrar la suma de cada una de las diagonales de izquierda a derecha despues sumar los 2 elementos que quedan solos y mostrar el resultado.*/
	
	
	return 0;
}
