#include <stdio.h>
#include <conio.h>
#define ULT 9
#define MAX 1000	

int main(int argc, char *argv[]) {
	/* Utilizacion de arreglos*/
	int lista[ULT]={0,4,78,5,32,9,77,1,23};
	int i,j,k,l,m,cont,aux,n,a;
	int lista1[ULT];
	int lista2[ULT];
	cont = 0;
	

	
	for (j = 0;j<ULT;j++) /* Obtencion de datos para cada posicion del array LISTA1 */ 
	{ 
		printf("Ingresar el elemento %d para el array LISTA1\n",j);
		scanf("%d",&lista1[j]);
		printf("Posicion del arreglo LISTA1: %d\n,>>Valor guardado en dicha posicion: %d\n\n<<",j,lista1[j]);
		
	}
	for (i = 0;i<ULT;i++) /* Como mostrar por pantalla los elementos de un array. LISTA */ 
	{ 
		printf("Posicion del arreglo LISTA: %d\nValor guardado en dicha posicion %d\n\n",i,lista[i]);
		
	}
	for (k = 0; k < ULT;k++)/* Comparacion de cual es el menor elemento entre los arreglos LISTA1 Y LISTA, el menor de estos es asignado a
		la misma posicion en un arreglo separado llamado lISTA2*/
	{ 
		if (lista[k]<lista1[k])
		{
			lista2[k] = lista[k];
		}
		else if (lista1[k]<lista[k])
		{
			lista2[k] = lista1[k];
		}
		else if (lista[k] == lista1[k])
		{
			lista2[k] = lista[k];
		}
	}
	for (l = ULT;l<ULT;l--)/* Muestra por pantalla los elementos obtenidos previamente de LISTA2 al revez, de posicion 8 a posicion 0*/ 
	{ 
		printf("Posicion del arreglo LISTA2 %d\n\n Valor guardado en dicha posicion: %d\n",l,lista2[l]);
	}
	/* Bucle para controlar la obtencion correcta de datos mayores */ 
	do
	{
		printf("Ingresa por teclado la posicion que quiere revisar del arreglo LISTA2\n");
		scanf("%d",&l);
		
		if (l >= 0 && l < ULT){
			printf("El valor guardado en la posicion ingresada es: %d\n",lista2[l]);
		}else{
			printf(">>DATO INCORRECTO<< , Por favor ingrese una posicion valida (Tamnio del vector 0 a 8)\n");
		}
	}while(l <= 0);
	
	printf("Ingrese un valor para revisar si esta en la lista.\n");
	scanf("%d",&a);
	for (m = 0;m<ULT;m++)
	{
		if (lista2[m] == a)
		{
			cont++;
			printf("El valor ingresado: %d fue encontrado %d veces en el array, en la posicion %d\n\n\n\n",a,cont,l);
		}
	}
	
	n = ULT;
	
	for (i = 0;i < n;i++){
		for (j = 0;j<n - i - 1;j++){
			if (lista2[j] > lista2[j+1]){
				aux = lista2[j];
				lista2[j] = lista2[j+1];
			    lista2[j+1] = aux;
			}
		}
	}
	printf("El array lista2 ordenado en forma ascendente es:\n");
	for (i = 0; i < n;i++){
		printf("%d\n",lista2[i]);
	}
	
	return 0;
}


	/* 
	Ejercicio 1: Indicar si es posible ordenar un arreglo con elementos repetidos usando el metodo de la burbuja.
	Ejercicio 2: Modificar el metodo de ordenamiento de la burbuja, para ordenar de mayor a menor.
	Ejercicio 3: Verificar si la busqueda binaria funciona para un arreglo ordenado con elementos repetidos, si es asi, modificar el algoritmo
	de tal manera que me indique cuantas veces aparece el elemento repetido.
	Ejercicio 4: operacion elemimacion, realizar los programas de eliminacion que se adecuen a cada una de las situaciones planteadas. */ 

