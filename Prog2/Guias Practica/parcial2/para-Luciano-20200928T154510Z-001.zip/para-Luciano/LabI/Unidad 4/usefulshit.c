/* n = dimension del arreglo */
/* Mostrar un array. */

void imprimirArr(int arr[], int n){
    int i;
    for (i = 0;i < n; i++){
        printf("%d ",arr[i]);
    }
    printf(" ");
}

/* ordenamiento por burbuja de menor a mayor */
void burbujaMenor(int arr[], int n){
    int i, j, t;
    for (i = 0; i < n - 1; i++){
        for (j = 0; j < n - i - 1; j++){
            if (arr[j] > arr[j+1]){
                t = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = t;
            }
        }

    }
    
    
/* ordenamiento por burbuja de mayor a menor */
void burbujaMayor(int arr[], int n){
    int i, j, t;
    for (i = 0; i < n - 1; i++){
        for (j = 0; j < n - i - 1; j++){
            if (arr[j] < arr[j+1]){
                t = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = t;
            }
        }

    }

}


/* busqueda binaria  */
void busquedaBinaria(int arr[], int elemento, int n) {
   int f = 0,mitad;
   
   while (f <= n) {
	  mitad = (f+n)/2;

	  if (arr[mitad] == elemento) {
         printf("\nElemento : %d encontrado en la posicion: %d.\n", elemento, mitad+1);
         break;
	  }
      else if (arr[mitad] < elemento){
         f = mitad + 1;    
      }else{
         n = mitad - 1;\
        }
   }
   if (f > n){
      printf("\nElemento %d no fue encontrado en el array.\n",elemento);
   }
}


/* ordenamiento por insercion */
void insertionSort(int arr[], int n) 
{ 
    int i, key, j; 
    for (i = 1; i < n; i++) { 
        key = arr[i]; 
        j = i - 1; 
  
        while (j >= 0 && arr[j] > key) { 
            arr[j + 1] = arr[j]; 
            j = j - 1; 
        } 
        arr[j + 1] = key; 
    } 
} 

/* Merge de 2 arrays de dimension = n en un array de dimension m = 2*n */

for (i = 0; i <  n; i++){
        arr3[i] = arr1[i];
    }
    printf("Contenido de arr3 hasta el momento: ");
    imprimirArr(arr3,n);
    printf("\n");
    for (i = 0, j = n;((j < m) && (i < n)) ; i++, j++){

        arr3[j] = arr2[i];

    }
	
/*merge de 2 arrays con dimensiones diferentes en un array que sea dimension3 = dimension1 + dimension2 */
	 d3 = d2 + d1;
         printf("valor de d3 = %d\n",d3);

    for (i = 0; i < d1; i++){
        arr3[i] = arr1[i];
    }
    printf("Contenido de arr3 hasta el momento: ");
    imprimirArr(arr3,d3);
    printf("\n");
    for (i = 0, j = d1;((j < d3) && (i < d2)) ; i++, j++){
        arr3[j] = arr2[i];
    }
    printf("Contenido final de arr3: ");
    imprimirArr(arr3,d3);
    
