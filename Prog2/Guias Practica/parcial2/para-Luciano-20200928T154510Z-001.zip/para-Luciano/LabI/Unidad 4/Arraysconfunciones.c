#include <stdio.h>
/*Dado un arreglo de 10 enteros, ingresar dos posiciones diferentes e intercambiar sus contenidos */
void burbuja(int a[], int b);
void imprimirArr(int a[], int b);

int main(int argc, char *argv[]){
    int i,j,n;
    int arr1[100];
    do{
    printf("Ingrese la dimension del arreglo numero 1.\n");
    scanf("%d",&n);
    if (n <= 0){
        printf("La dimensioon ingresada es incorrecta.\n");
    }
    }while(n<=0);
    printf("Ingrese 10 enteros para arr1: ");
    for (i = 0; i < n; i++){
        scanf("%d",&arr1[i]);
    }
    burbuja(arr1,n);
    printf("El primer arreglo ordenado de menor a mayor a continuacion: ");
    imprimirArr(arr1,n);
    printf("Numero de elementos del arr1: %ld\n",sizeof(arr1)/sizeof(arr1[0]));

    return 0;
}
void burbuja(int a[], int b){
    int i, j, t;
    for (i = 0; i < b - 1; i++){
        for (j = 0; j < b - i - 1; j++){
            if (a[j] > a[j+1]){
                t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }
        }

    }

}
void imprimirArr(int a[], int b){
    int i;
    for (i = 0;i < b; i++){
        printf("%d ",a[i]);
    }
    printf("\n");
}


