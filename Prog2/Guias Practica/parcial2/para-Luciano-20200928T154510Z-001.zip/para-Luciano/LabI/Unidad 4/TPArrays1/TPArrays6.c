#include <stdio.h>
#include <curses.h>
/* Diseña un programa que cargue un arreglo con los 20 primeros números enteros 
y los muestre en pantalla en orden descendente.  */
void burbuja_mayor(int arr[], int n);
void imprimirArr(int arr[], int n);
int main(int argc, int *argv[]){

    int arr1[20];
    int i;
    printf("Ingrese elementos para llenar el Array 1");
    for (i = 0; i < 20;i++){
        scanf(" %d",&arr1[i]);
    }
    burbuja_mayor(arr1,20);
    printf("Los elementos ordenados de manera descendente para el array dado: ");
    imprimirArr(arr1,20);
    
    return 0;
}
void burbuja_mayor(int arr[], int n){
    int i, j, t;
    for (i = 0; i < n - 1; i++){
        for (j = 0; j < n - i - 1; j++){
            if (arr[j] < arr[j+1]){
                t = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = t;
            }
        }
    }
}
void imprimirArr(int arr[], int n){
    int i;
    for (i = 0;i < n; i++){
        printf("%d ",arr[i]);
    }
    printf(" ");
}
