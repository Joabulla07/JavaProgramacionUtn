#include <stdio.h>
/*    1. Realizar un programa en el que se ingresen 10 enteros. Se pide:
        a. Sumar sus elementos. Mostrar el resultado. Calcular el promedio.
        b. Multiplicar sus elementos. Mostrar el resultado.
        c. Cantidad de números primos. Mostrar los números primos.
        d. Mostrar los elementos que son mayores al promedio.
 */
int chequearprimo(int *a);
int main(int argc, char *argv){
    int array[10];
    int i,j=0,suma=0,producto=1,primos;
    float promedio;
    printf("Ingrese 10 enteros: ");
    for (i = 0; i < 10; i++){
        scanf("%d",&array[i]);
    }
    for (i = 0; i < 10; i++){
        suma += array[i];
    }
    promedio = suma / 10;
    for (i = 0; i < 10; i++){
        producto*=array[i];
    }
    for (i = 0; i < 10; i++){
        if (array[i] > promedio){
            j++;
        }
    }
    
    printf("La suma de todos los numeros dentro del array es igual a: %d\nSu promedio es: %.3f\n",suma,promedio);
    printf("El producto de todos los numeros dentro del array entre si es de: %d\n",producto);
    printf("La cantidad de numeros que son mas grandes que el promedio es de: %d\n",j);    
    

for (i = 0; i < 10; i++){
        primos = chequearprimo(&array[i]);

        if (primos == 1){
            printf("%d es primo.\n",array[i]);
        }else{
            printf("%d no es primo.\n",array[i]);
        }
    }


    return 0;
}
int chequearprimo(int *a){
    int c;

    for (c = 2; c <= *a - 1; c++){
        if (*a % c == 0){
            return 0;
        }
    }
    if (c == *a){
            return 1;
        }
}
