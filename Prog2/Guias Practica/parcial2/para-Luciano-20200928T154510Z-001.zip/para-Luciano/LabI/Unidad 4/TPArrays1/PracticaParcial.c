#include <stdio.h>
#include <math.h>
/* hacer a + b = c y ordenarlo por bubble sort */
/*2)se tiene una cadena de caracteres cuya longtud es la misma q la del array 3 que indica en su contenido los cambios que deben 
hacerse en
el array3:
si el contenido de la cadena es g, significa que no hay que hacer cambios en el array3,
si el contenido es una m signfica que hay que calcular el cuadrado del contenido de array3 y actualizar su valor.
si es una d significa que hay que sumarle el triplo de su valor y actualizar el contenido, todas estas operaciones se deben realizar
mediante funciones.
documentar y chquear datos. */
void burbujaMenor(int arr[], int n);
void imprimirArr(int arr[], int n);
int operacionM(int arr[], int i);
int operacionD(int arr[],int i);
void operacionG(int i);
int main(int argc, char *argv[]) {
	int d1,d2,d3,d4,i,j;
	int arr1[100],arr2[100],arr3[100];
    char arr4[100];
	do{
		printf("\n Ingrese la dimension del array A: ");
		scanf("%d",&d1);
		printf("\nIngrese la dimension del array B: ");
		scanf("%d",&d2);
		if (d1 <= 1 || d2 <= 1){
			printf("\nPorfavor, asegurese que las dimensiones sean mayor a 1.");
		}
	}while (d2 <= 1 || d1 <= 1);
    
    printf("Ingrese elementos para el array 1: ");
    for (i = 0; i < d1; i++){
        scanf("%d",&arr1[i]);
    }
    burbujaMenor(arr1,d1);
    imprimirArr(arr1,d1);

    printf("\nIngrese elementos para el array 2: ");
    for (i = 0; i < d2; i++){
        scanf("%d",&arr2[i]);
    }
    burbujaMenor(arr2,d2);
    imprimirArr(arr2,d2);
    d3 = d2 + d1;
    d4 = d3;

    printf("valor de d3 = %d\n",d3);

    for (i = 0; i < d1; i++){
        arr3[i] = arr1[i];
    }
    printf("Contenido de arr3 hasta el momento: ");
    imprimirArr(arr3,d1);
    printf("\n");
    for (i = 0, j = d1;((j < d3) && (i < d2)) ; i++, j++){
        arr3[j] = arr2[i];
    }
    printf("Contenido final de arr3: ");
    imprimirArr(arr3,d3);
    printf("\n");
    printf("Ingrese %d caracteres: \n",d4);
    i = 0;
    while (i < d4){
        scanf("%c",&arr4[i]);
        i++;
    }
    for (i = 0; i < d4; i++){
        if ((arr4[i] == 'M') || (arr4[i] == 'm')){
            arr3[i] = operacionM(arr3,i);
        }else if ((arr4[i] == 'D') || (arr4[i] == 'd')){
            arr3[i] = operacionD(arr3,i);
        }else if ((arr4[i] == 'G') || (arr4[i] == 'g')){
            operacionG(i);
        }else if (i == d4 - 1){
            arr4[i] = '\0';
        }
    }
    printf("Despues de las operaciones realizadas, el contenido de array3 es: ");
    imprimirArr(arr3,d3);
    printf("\n");
    printf("El contenido de array4 es: ");
    for(i = 0; i < d4; i++){
        printf("%c ",arr4[i]);
    }
    printf(" ");
	return 0;
}
void burbujaMenor(int arr[], int n){
    int i, j, t;
    for (i = 0; i < n - 1; i++){
        for (j = 0; j < n - i - 1; j++){
            if (arr[j] > arr[j+1]){
                t = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = t;
            }
        }
    }
}
void imprimirArr(int arr[], int n){
    int i;
    for (i = 0;i < n; i++){
        printf("%d ",arr[i]);
    }
    printf(" ");
}
int operacionM(int arr[], int i){
    int aux;
    aux = (arr[i] * arr[i]);
    return aux;
}
int operacionD(int arr[],int i){
    int aux;
    aux = (arr[i] + (arr[i] * 3));
    return aux;

}
void operacionG(int i){
    printf("No se hizo cambios en el elemento %d del array.\n",i);
}
