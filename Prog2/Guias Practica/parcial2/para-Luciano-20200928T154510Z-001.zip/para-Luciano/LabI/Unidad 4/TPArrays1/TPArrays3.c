#include <stdio.h>
/*Dada un arreglo de 10 números enteros positivos, generar un nuevo vector con aquellos números que son múltiplos de 3 
y otro con el resto de los elementos del vector original.
Mostrar los tres vectores. */
int main(int argc, char *argv[]){
    int array1[100],array2[100],array3[100];
    int i,j=0,k=0,n=10;
    printf("Ingrese 10 enteros para el array1.\n");
    for (i = 0; i < n; i++){
        scanf("%d",&array1[i]);
    }
    for (i = 0; i < n; i++){
        if (array1[i] % 3 == 0){
            array2[j] = array1[i];
            j++;
        }else{
            array3[j] = array1[i];
            k++;
        }
        
    }
    printf("Contenido del primer array: ");
    for (i = 0; i < n; i++){
        printf(" %d ",array1[i]);
    }
    printf("\nContenido del segundo array (multiplos de 3):");
    for (i = 0; i < n; i++){
        printf("\n %d ",array2[i]);
    }
    printf("\nContenido del tercer array (sobras):");
    for (i = 0; i < n; i++){
        printf("\n %d ",array3[i]);
    }


    return 0;
}
