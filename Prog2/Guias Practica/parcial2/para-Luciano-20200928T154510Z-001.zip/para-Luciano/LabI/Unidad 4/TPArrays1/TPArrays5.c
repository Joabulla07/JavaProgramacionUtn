#include <stdio.h>
/* Dados dos arreglos ordenado de mayor a menor sin elementos repetidos de 10 elementos cada uno. Se pide:
            i. Generar un nuevo vector ordenado que contenga a ambos vectores. Mostrar el resultado.
            ii. Mostrar el vector de menor a mayor.
            iii. aplicar busqueda binaria por los loles */
            
void burbujaMayor(int a[], int b);
void burbujaMenor(int a[], int b);
void imprimirArr(int a[], int b);
void busquedaBinaria(int arr[], int elemento, int n);


int main(int argc, char *argv[]){
    int i,j,n,m,buscar;
    int arr1[10],arr2[10],arr3[20];

        n = 10;
        m = 20;
    printf("Ingrese 10 enteros para arr1: ");
    for (i = 0; i < n; i++){
        scanf("%d",&arr1[i]);
    }
    printf("Ingrese 10 enteros para arr2: ");
    for (i = 0; i < n; i++){
        scanf("%d",&arr2[i]);
    }
    burbujaMayor(arr1,n);
    burbujaMayor(arr2,n);
    printf("El primer arreglo ordenado de mayor a menor a continuacion: ");
    imprimirArr(arr1,n);
    printf("\n");
    printf("El segundo arreglo ordenado de mayor a menor a continuacion: ");
    imprimirArr(arr2,n);
    printf("\n");

    for (i = 0; i <  n; i++){
        arr3[i] = arr1[i];
    }
    printf("\n");
    for (i = 0, j = n;((j < m) && (i < n)) ; i++, j++){

        arr3[j] = arr2[i];

    }
    burbujaMenor(arr3,m);
    printf("Contenido total de arr3: ");
    imprimirArr(arr3,m);
    printf("\n");
    printf("Ingrese un numero a buscar en arr3: \n");
    scanf("%d",&buscar);
    busquedaBinaria(arr3,buscar,m);
    
    return 0;
}
void burbujaMayor(int arr[], int n){
    int i, j, t;
    for (i = 0; i < n - 1; i++){
        for (j = 0; j < n - i - 1; j++){
            if (arr[j] < arr[j+1]){
                t = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = t;
            }
        }

    }

}
void burbujaMenor(int arr[], int n){
    int i, j, t;
    for (i = 0; i < n - 1; i++){
        for (j = 0; j < n - i - 1; j++){
            if (arr[j] > arr[j+1]){
                t = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = t;
            }
        }

    }

}
void imprimirArr(int arr[], int n){
    int i;
    for (i = 0;i < n; i++){
        printf("%d ",arr[i]);
    }
    printf(" ");
}
void busquedaBinaria(int arr[], int elemento, int n) {
   int f = 0,mitad;
   
   while (f <= n) {
	  mitad = (f+n)/2;

	  if (arr[mitad] == elemento) {
         printf("\nElemento : %d encontrado en la posicion: %d.\n", elemento, mitad+1);
         break;
	  }
      else if (arr[mitad] < elemento){
         f = mitad + 1;    
      }else{
         n = mitad - 1;\
        }
   }
   if (f > n){
      printf("\nElemento %d no fue encontrado en el array.\n",elemento);
   }
}
