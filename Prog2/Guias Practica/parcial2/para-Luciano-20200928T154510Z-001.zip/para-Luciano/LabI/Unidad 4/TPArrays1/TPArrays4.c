#include <stdio.h>
#include <curses.h>

/* Dado un arreglo de 10 enteros, ingresar dos posiciones diferentes e intercambiar sus contenidos. */
void imprimirArr(int arr[], int b);
void intercambio(int arr1[], int indice1, int arr2[], int indice2);
int main(int argc, char *argv[]){
    int arr1[100], arr2[100];
    int n,i,ix1,ix2;
    printf("Ingrese la dimension de los 2 arrays a intercambiar sus elementos.\n");
    do{
        scanf("%d",&n);
        if (n <= 0){
            printf("Numero de dimension invalido.\n");
        }
    }while(n <= 0);
    printf("Ingrese elementos para guardar en el array1.\n");
    for (i = 0; i < n; i++){
        scanf("%d",&arr1[i]);
    }
    printf("Ingrese elementos para guardar en el array2.\n");
    for (i = 0; i < n; i++){
        scanf("%d",&arr2[i]);
    }
    printf("Los elementos ingresados para el array 1 son: ");
    imprimirArr(arr1, n);
    printf("\n");
    printf("Los elementos ingresados para el array 2 son: ");
    imprimirArr(arr2, n);
    printf("\n");

    printf("Ingrese la posicion del array 1 para usar en el intercambio: \n");
    scanf("%d",&ix1);
    printf("Ingrese la posicion del array 2 para usar en el intercambio: \n");
    scanf("%d",&ix2);

    intercambio(arr1,ix1,arr2,ix2);

    printf("El array 1 despues del intercambio: ");
    imprimirArr(arr1, n);
    printf("\n");
    printf("El array 2 despues del intercambio: ");
    imprimirArr(arr2, n);
    printf("\n");

    
    return 0;
}
void imprimirArr(int arr[], int n){
    int i;
    for (i = 0; i < n; i++){
        printf("%d ",arr[i]);
    }
    printf(" ");
}
void intercambio(int arr1[], int indice1, int arr2[], int indice2){
    int aux;
    aux = arr1[indice1];
    arr1[indice1] = arr2[indice2];
    arr2[indice2] = aux;
}
