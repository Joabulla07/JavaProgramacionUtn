#include <stdio.h>
#include <conio.h>
#define DIM 10
/* a) dado un arreglo de 10 numeros enteros positivos generar un nuevo vector con aquellos numeros que son multiplos 
de 3 y otros con el resto de los elementos del vector, mostrar los tres vectores por pantalla, utilizar una funcion
para determinar si el elemento es multiplo de 3.
b) con el arreglo original ingresar 2 posiciones del arreglo e intercambiar su contenido
c) ordenar el arreglo b de mayor a menor y mostrar por pantalla, ordenar el arreglo c de menor a mayor y mostrar 
por pantalla.
d) eliminar del arreglo original los elementos repetidos.
e) usando busqueda binaria indicar si un elemento ingresado por teclado se encuentra en el arreglo c
*/
int multiplo3(int a);
int resto(int a);
int main(int argc, char *argv[]) {
	int arrayA[DIM],arrayB[DIM],arrayC[DIM]; /*Definicion de vectores dimension DIM = 10*/
	int i = 0,j = 0,k = 0;
	int pos1,pos2,paux;
	
	do{
		do{
			printf("Ingrese un valor para la posicon %d del vector A\n",i);
			scanf("%d",&arrayA[i]);
			if (arrayA[i] < 0){
				printf("Por favor ingrese un valor entero y positivo.\n");
			}
		}while(arrayA[i] < 0);
		i++;
	}while(i < DIM);
	for (i = 0;i<DIM;i++){
		printf("La posicion %d del arreglo A contiene: %d\n\n\n",i,arrayA[i]);
	}
	for (j = 0;j<DIM;j++){
		arrayB[j] = multiplo3(arrayA[j]);
		if (arrayB[j] != 0){
			printf("La posicion %d del arreglo B contiene: %d\n\n\n",j,arrayB[j]);
		}
	}
	for (k = 0;k<DIM;k++){
		arrayC[k] = resto(arrayA[k]);
		if (arrayC[k] != 0){
			printf("La posicion %d del arreglo C contiene: %d\n\n\n",k,arrayC[k]);
		}
	}
	printf("Ingrese 2 posiciones del arreglo A para intercambiar los valores entre esas 2 posiciones.\n");;
	scanf("%d %d",&pos1,&pos2);
	arrayA[paux] = arrayA[pos1];
	arrayA[pos1] = arrayA[pos2];
	arrayA[pos2] = arrayA[paux];
	for (i = 0;i<DIM;i++){
		printf("El arreglo A con posiciones intercambiadas es: %d\n\n",arrayA[i]);
	}
	
	
	
	
	return 0;
}
int multiplo3(int a){
	int c,b;
	
	for (c=0;c<DIM;c++){
		if (a % 3 == 0){
			b = a;
			return b;
		}
	}
}



int resto(int a){
	int c,d;
	for (c = 0;c<DIM;c++){
		if (a % 3 != 0){
			d = a;
			return d;
		}
	}
	
}
