/* Diseniar un programa que permita generar un archivo de texto  que permita cargar 5 nombres separados por punto. mostrar el contenido del archivo un nombre abajo del otro.*/
#include <stdio.h>
#include <string.h>
#define a "nombres.dat"
#define tam 50
void apertura_archivo();
void cerrar_archivo();
void mostrar_archivo();
void escribir();
void inicializar_array();
int chequear_caracteres();

FILE *archivo;
int i,cant;
char caracter;
char string[tam];

int main(){
	apertura_archivo();
	escribir();
	cerrar_archivo();
	mostrar_archivo();
	return 0;
}
/* funcion que permite abrir el archivo para la escritura del mismo. */
void apertura_archivo(){
	if ((archivo = fopen(a,"w")) == NULL){
		printf("\n El archivo no ha podido ejecutarse.");
	}
}
/* Funcion para cerrar el archivo */
void cerrar_archivo(){
	if(fclose(archivo) != 0){
		printf("\nHubo un problema al cerrar el archivo.\n");
	} else {\
		printf("\nEl archivo fue cerrado correctamente.\n");
	}
}
/* Funcion para mostrar los datos del archivo. */
void mostrar_archivo(){
	if ((archivo = fopen(a,"r")) == NULL){
		printf("\nEl archivo no pudo ser abierto.");
	}
	printf("\n\nMostrando datos del archivo.\n\n");
	while(!feof(archivo)){
		
		caracter = fgetc(archivo);
		if(caracter == '.'){
			printf("\n");
		} else {
			printf("%c",caracter);
		}
	}
	printf("\n");
	
	cerrar_archivo();
}
/* funcion inserta los datos en el archivo una vez que se verifica la consistencia de los datos */
void escribir(){
	do { 
		if(cant != 5 && cant > 1){
			inicializar_array();
			cant=1;
			printf("\nEl total de nombres debe de ser 5.(seguidos de un punto entre cada nombre.)\n");
			printf(" Ej:lorena.micaela.mauricio.ezequiel.emiliano.\n");
			scanf("%s",&string);
		} else {
			inicializar_array();
			cant=1;
			printf("<< Ingrese cinco nombres: (seguidos de un punto entre cada nombre.)\n");
			printf(" Ej:lorena.micaela.mauricio.ezequiel.emiliano.\n");
			scanf("%s",&string);
		}
		if(chequear_caracteres() == 5){
			for(i = 0; i < tam; i++){
				if(string[i] != '*'){
					fputc(string[i],archivo);
				}
			}
		}
	} while(cant != 5);
}
/* Funcion que inicializa el array para ingresar texto */
void inicializar_array(){
	for(i = 0; i < tam; i++){
		string[i] = '*';
	}
}
/*funcion que chequea cuantas cantiidades de caracteres se ingresan.*/
int chequear_caracteres(){
	for(i = 0; i < tam; i++){
		if(string[i] == '.'){
			cant++;
		}
	}
	return cant;
}
