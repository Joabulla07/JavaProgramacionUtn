#include <stdio.h>
#include <conio.h>

int main () {
  int a=7;
  float b=8.2;
  char c='s';
  
  printf("%d%.1f%c\n",a,b,c);
  printf("%d\t %f\t %c ",a,b,c);
  
// El primero muestra los caracteres juntos como si estuvieramos construyendo 78.2s en cambio el segundo printf muestra los caracteres separados.
// \t es para dar una tabulacion despues de mostrar un texto o un valor y significa tabulacion literalmente.
  
}
