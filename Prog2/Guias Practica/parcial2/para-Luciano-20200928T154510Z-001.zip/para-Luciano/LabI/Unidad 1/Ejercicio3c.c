#include <stdio.h>

int main() {

printf("Matematicas\n");
printf("Sistemas de procesamiento de datos\n");
printf("Programacion\n");
printf("Ingles\n");
printf("Laboratorio de Computacion\n");

}
