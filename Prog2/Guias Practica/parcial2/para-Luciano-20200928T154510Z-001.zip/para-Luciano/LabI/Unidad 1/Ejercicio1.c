#include <stdio.h>

int main(){
int registro;
int archivo;
int return // Return no es un identificador valido porque es una palabra reservada en el lenguaje.
int $impuesto; // identificador invalido, el primer caracter de un identificador solo puede contener letras a-z y A-Z o guion bajo ' _'
int nombre;
int nombre y direccion;
int nombre_y_direccion;
int nombre-y-direccion; // Identificador invalido ya que los identificadores no pueden poseer guiones., solo caracters desde la a-z min y A-Z mayuscula y ' _'
int 123-45-6789 // identificador invalido ya que no se puede identificar con guiones.
}
