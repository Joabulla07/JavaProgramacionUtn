#include <stdio.h>
#include <math.h>

int main() {
/*Ingresar un valor entero por teclado, calcular y mostrar por pantalla:
a) La quinta parte de dicho valor
b) La mitad de la quinta parte
c) El cuadrado de dicho valor (usar funcion predefinida en C)*/ 
int a;
int x;
int y;
int z;

printf("Ingrese un valor entero por teclado\n");
scanf("%d",&a);

x = a / 5;
printf("La quinta parte del valor ingresado es: %d\n",x);
y = x / 2;
printf("La mitad de la quinta parte del valor ingresado es: %d\n",y);
z = pow(y,2);
printf("El cuadrado de la mitad de la quinta parte del valor ingresado es: %d\n",z);

return 0;

}
