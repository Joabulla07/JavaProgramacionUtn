#include <stdio.h>
#include <conio.h>


int main()

{
int edad;
printf("Ingrese su edad:   \n");
scanf("%d",&edad);

if (edad >= 18)
{ printf("Sos mayor de edad capo, felicidades.\n");
}
else
{
printf("Sos menor de edad capo, volve cuando seas grande");


getchar();




}


}

