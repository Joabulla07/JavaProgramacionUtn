#include <stdio.h>
#include <conio.h>

int main(){
int a;
int b;
int suma;
int diferencia;
int x;

printf("Ingrese el valor del primer numero: ");
scanf("%d",&a);
printf("Ingrese el valor del segundo numero: ");
scanf("%d",&b);

suma = a + b;
diferencia = a - b;
x = a * b;

printf("La suma de los dos numeros ingresados es: %d\n",suma);
printf("La diferencia de los dos numeros ingresados es: %d\n",diferencia);
printf("El producto de los dos numeros ingresados es: %d\n",x);

return (0);

}
