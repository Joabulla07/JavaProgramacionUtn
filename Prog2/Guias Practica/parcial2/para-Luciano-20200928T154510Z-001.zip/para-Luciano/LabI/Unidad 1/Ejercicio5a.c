#include <stdio.h>
#include <conio.h>

int main() {

int a;
int b;
int c;

printf("Ingrese el valor del primer numero\n");
scanf("%d",&a);
printf("Ingrese el valor del segundo numero\n");
scanf("%d",&b);
c = a;
a = b;
b = c;
printf("El primer valor ingresado es: %d\n",a);
printf("El segundo valor ingresado es: %d\n",b);

return 0;

}

