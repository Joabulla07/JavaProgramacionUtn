#include <stdio.h>

int main (){

printf("Benitez,Mauricio Ezequiel.\n");
printf("17 de agosto de 1995.\n");
printf("***************************************");
printf("\n");
printf("**Tecnico Superior en Programacion**\n");
printf("   Laboratorio de Computacion I\n");
printf("***************************************");

}
