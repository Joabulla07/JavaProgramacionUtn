#include <stdio.h>
#include <conio.h>
#define a 7
#define b 8.2
#define c 's'

int main()
{

printf("Benitez, Mauricio Ezequiel.\n");
printf("%d%f%c\n",a,b,c);
printf("%d\t%f\t%c\n",a,b,c);
 return 0;

}
