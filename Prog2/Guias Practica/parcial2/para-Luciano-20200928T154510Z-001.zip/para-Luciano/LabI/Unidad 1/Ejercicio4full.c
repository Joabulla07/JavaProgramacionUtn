#include <stdio.h>
#include <conio.h>
int main(){
// Definicion de variables 
int v1;
int v2;
int producto;
int suma;
int suma2;

printf("Ingrese una variable entera\n");
scanf ("%d", &v1);
printf("Ingrese una segunda variable entera\n");
scanf ("%d", &v2);

// Resolucion
printf("La primer variable que fue ingresada fue: %d\n",v1);
printf("La segunda variable que fue ingresada fue: %d\n",v2);
producto = v1 * v2;
printf("El producto entre las 2 variables es: %d\n",producto);
suma = v1 + v2;
printf("La suma de las 2 variables es: %d\n",suma);
suma2 = suma * 2;
printf("El producto de la suma hecha por 2 es: %d\n",suma2);

return 0;

}
