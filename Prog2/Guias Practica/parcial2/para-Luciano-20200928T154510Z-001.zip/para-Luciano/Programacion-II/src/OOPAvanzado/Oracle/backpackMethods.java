package OOPAvanzado.Oracle;

public interface backpackMethods {

    public boolean backpackIsFilled();

    public int zipperQty();

    public String material();
}