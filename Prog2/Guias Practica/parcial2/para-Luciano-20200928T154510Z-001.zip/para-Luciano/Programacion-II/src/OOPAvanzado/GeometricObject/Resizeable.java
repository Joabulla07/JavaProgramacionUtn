package OOPAvanzado.GeometricObject;

public interface Resizeable {

    public abstract int resize(int percent);

}
