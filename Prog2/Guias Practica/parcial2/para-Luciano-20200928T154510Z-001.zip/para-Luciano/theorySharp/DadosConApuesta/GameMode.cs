namespace DadosConApuesta
{
    public enum GameMode
    {
        Conservative, Risky, Desperate
    }
}