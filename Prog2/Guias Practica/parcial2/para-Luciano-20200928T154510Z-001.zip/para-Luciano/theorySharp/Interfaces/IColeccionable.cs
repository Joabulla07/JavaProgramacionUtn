namespace Interfaces
{
    public interface IColeccionable
    {
        public string Titulo();
        public string Describir();
    }
}