﻿namespace Calculator
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sixBtn = new System.Windows.Forms.Button();
            this.threeBtn = new System.Windows.Forms.Button();
            this.fiveBtn = new System.Windows.Forms.Button();
            this.twoBtn = new System.Windows.Forms.Button();
            this.oneBtn = new System.Windows.Forms.Button();
            this.fourBtn = new System.Windows.Forms.Button();
            this.sqrtBtn = new System.Windows.Forms.Button();
            this.nineBtn = new System.Windows.Forms.Button();
            this.powerOfBtn = new System.Windows.Forms.Button();
            this.eightBtn = new System.Windows.Forms.Button();
            this.sevenBtn = new System.Windows.Forms.Button();
            this.fractionSignBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.clearEntryBtn = new System.Windows.Forms.Button();
            this.moduloSignBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.divisionSignBtn = new System.Windows.Forms.Button();
            this.productSignBtn = new System.Windows.Forms.Button();
            this.minusSignBtn = new System.Windows.Forms.Button();
            this.plusSign = new System.Windows.Forms.Button();
            this.equalsSignBtn = new System.Windows.Forms.Button();
            this.dotBtn = new System.Windows.Forms.Button();
            this.zeroBtn = new System.Windows.Forms.Button();
            this.box_Content = new System.Windows.Forms.TextBox();
            this.lblCurrentOperation = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // sixBtn
            // 
            this.sixBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.sixBtn.Location = new System.Drawing.Point(211, 238);
            this.sixBtn.Name = "sixBtn";
            this.sixBtn.Size = new System.Drawing.Size(80, 26);
            this.sixBtn.TabIndex = 23;
            this.sixBtn.Text = "6";
            this.sixBtn.UseVisualStyleBackColor = true;
            this.sixBtn.Click += new System.EventHandler(this.button_click);
            // 
            // threeBtn
            // 
            this.threeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.threeBtn.Location = new System.Drawing.Point(211, 287);
            this.threeBtn.Name = "threeBtn";
            this.threeBtn.Size = new System.Drawing.Size(80, 26);
            this.threeBtn.TabIndex = 22;
            this.threeBtn.Text = "3";
            this.threeBtn.UseVisualStyleBackColor = true;
            this.threeBtn.Click += new System.EventHandler(this.button_click);
            // 
            // fiveBtn
            // 
            this.fiveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.fiveBtn.Location = new System.Drawing.Point(113, 238);
            this.fiveBtn.Name = "fiveBtn";
            this.fiveBtn.Size = new System.Drawing.Size(80, 26);
            this.fiveBtn.TabIndex = 21;
            this.fiveBtn.Text = "5";
            this.fiveBtn.UseVisualStyleBackColor = true;
            this.fiveBtn.Click += new System.EventHandler(this.button_click);
            // 
            // twoBtn
            // 
            this.twoBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.twoBtn.Location = new System.Drawing.Point(113, 287);
            this.twoBtn.Name = "twoBtn";
            this.twoBtn.Size = new System.Drawing.Size(80, 26);
            this.twoBtn.TabIndex = 20;
            this.twoBtn.Text = "2";
            this.twoBtn.UseVisualStyleBackColor = true;
            this.twoBtn.Click += new System.EventHandler(this.button_click);
            // 
            // oneBtn
            // 
            this.oneBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.oneBtn.Location = new System.Drawing.Point(12, 287);
            this.oneBtn.Name = "oneBtn";
            this.oneBtn.Size = new System.Drawing.Size(80, 26);
            this.oneBtn.TabIndex = 19;
            this.oneBtn.Text = "1";
            this.oneBtn.UseVisualStyleBackColor = true;
            this.oneBtn.Click += new System.EventHandler(this.button_click);
            // 
            // fourBtn
            // 
            this.fourBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.fourBtn.Location = new System.Drawing.Point(12, 238);
            this.fourBtn.Name = "fourBtn";
            this.fourBtn.Size = new System.Drawing.Size(80, 26);
            this.fourBtn.TabIndex = 18;
            this.fourBtn.Text = "4";
            this.fourBtn.UseVisualStyleBackColor = true;
            this.fourBtn.Click += new System.EventHandler(this.button_click);
            // 
            // sqrtBtn
            // 
            this.sqrtBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.sqrtBtn.Location = new System.Drawing.Point(211, 144);
            this.sqrtBtn.Name = "sqrtBtn";
            this.sqrtBtn.Size = new System.Drawing.Size(80, 26);
            this.sqrtBtn.TabIndex = 29;
            this.sqrtBtn.Text = "x / x";
            this.sqrtBtn.UseVisualStyleBackColor = true;
            // 
            // nineBtn
            // 
            this.nineBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nineBtn.Location = new System.Drawing.Point(211, 190);
            this.nineBtn.Name = "nineBtn";
            this.nineBtn.Size = new System.Drawing.Size(80, 26);
            this.nineBtn.TabIndex = 28;
            this.nineBtn.Text = "9";
            this.nineBtn.UseVisualStyleBackColor = true;
            this.nineBtn.Click += new System.EventHandler(this.button_click);
            // 
            // powerOfBtn
            // 
            this.powerOfBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.powerOfBtn.Location = new System.Drawing.Point(113, 144);
            this.powerOfBtn.Name = "powerOfBtn";
            this.powerOfBtn.Size = new System.Drawing.Size(80, 26);
            this.powerOfBtn.TabIndex = 27;
            this.powerOfBtn.Text = "x * x";
            this.powerOfBtn.UseVisualStyleBackColor = true;
            // 
            // eightBtn
            // 
            this.eightBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.eightBtn.Location = new System.Drawing.Point(113, 190);
            this.eightBtn.Name = "eightBtn";
            this.eightBtn.Size = new System.Drawing.Size(80, 26);
            this.eightBtn.TabIndex = 26;
            this.eightBtn.Text = "8";
            this.eightBtn.UseVisualStyleBackColor = true;
            this.eightBtn.Click += new System.EventHandler(this.button_click);
            // 
            // sevenBtn
            // 
            this.sevenBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.sevenBtn.Location = new System.Drawing.Point(12, 190);
            this.sevenBtn.Name = "sevenBtn";
            this.sevenBtn.Size = new System.Drawing.Size(80, 26);
            this.sevenBtn.TabIndex = 25;
            this.sevenBtn.Text = "7";
            this.sevenBtn.UseVisualStyleBackColor = true;
            this.sevenBtn.Click += new System.EventHandler(this.button_click);
            // 
            // fractionSignBtn
            // 
            this.fractionSignBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.fractionSignBtn.Location = new System.Drawing.Point(12, 144);
            this.fractionSignBtn.Name = "fractionSignBtn";
            this.fractionSignBtn.Size = new System.Drawing.Size(80, 26);
            this.fractionSignBtn.TabIndex = 24;
            this.fractionSignBtn.Text = "1/x";
            this.fractionSignBtn.UseVisualStyleBackColor = true;
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.clearBtn.Location = new System.Drawing.Point(211, 101);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(80, 26);
            this.clearBtn.TabIndex = 32;
            this.clearBtn.Text = "C";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // clearEntryBtn
            // 
            this.clearEntryBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.clearEntryBtn.Location = new System.Drawing.Point(113, 101);
            this.clearEntryBtn.Name = "clearEntryBtn";
            this.clearEntryBtn.Size = new System.Drawing.Size(80, 26);
            this.clearEntryBtn.TabIndex = 31;
            this.clearEntryBtn.Text = "CE";
            this.clearEntryBtn.UseVisualStyleBackColor = true;
            this.clearEntryBtn.Click += new System.EventHandler(this.clearEntryBtn_Click);
            // 
            // moduloSignBtn
            // 
            this.moduloSignBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.moduloSignBtn.Location = new System.Drawing.Point(12, 101);
            this.moduloSignBtn.Name = "moduloSignBtn";
            this.moduloSignBtn.Size = new System.Drawing.Size(80, 26);
            this.moduloSignBtn.TabIndex = 30;
            this.moduloSignBtn.Text = "%";
            this.moduloSignBtn.UseVisualStyleBackColor = true;
            this.moduloSignBtn.Click += new System.EventHandler(this.operator_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.deleteBtn.Location = new System.Drawing.Point(312, 101);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(80, 26);
            this.deleteBtn.TabIndex = 35;
            this.deleteBtn.Text = "DEL";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // divisionSignBtn
            // 
            this.divisionSignBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.divisionSignBtn.Location = new System.Drawing.Point(312, 144);
            this.divisionSignBtn.Name = "divisionSignBtn";
            this.divisionSignBtn.Size = new System.Drawing.Size(80, 26);
            this.divisionSignBtn.TabIndex = 34;
            this.divisionSignBtn.Text = "/";
            this.divisionSignBtn.UseVisualStyleBackColor = true;
            this.divisionSignBtn.Click += new System.EventHandler(this.operator_Click);
            // 
            // productSignBtn
            // 
            this.productSignBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.productSignBtn.Location = new System.Drawing.Point(312, 190);
            this.productSignBtn.Name = "productSignBtn";
            this.productSignBtn.Size = new System.Drawing.Size(80, 26);
            this.productSignBtn.TabIndex = 33;
            this.productSignBtn.Text = "*";
            this.productSignBtn.UseVisualStyleBackColor = true;
            this.productSignBtn.Click += new System.EventHandler(this.operator_Click);
            // 
            // minusSignBtn
            // 
            this.minusSignBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.minusSignBtn.Location = new System.Drawing.Point(312, 238);
            this.minusSignBtn.Name = "minusSignBtn";
            this.minusSignBtn.Size = new System.Drawing.Size(80, 26);
            this.minusSignBtn.TabIndex = 38;
            this.minusSignBtn.Text = "-";
            this.minusSignBtn.UseVisualStyleBackColor = true;
            this.minusSignBtn.Click += new System.EventHandler(this.operator_Click);
            // 
            // plusSign
            // 
            this.plusSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.plusSign.Location = new System.Drawing.Point(312, 287);
            this.plusSign.Name = "plusSign";
            this.plusSign.Size = new System.Drawing.Size(80, 26);
            this.plusSign.TabIndex = 37;
            this.plusSign.Text = "+";
            this.plusSign.UseVisualStyleBackColor = true;
            this.plusSign.Click += new System.EventHandler(this.operator_Click);
            // 
            // equalsSignBtn
            // 
            this.equalsSignBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.equalsSignBtn.Location = new System.Drawing.Point(312, 330);
            this.equalsSignBtn.Name = "equalsSignBtn";
            this.equalsSignBtn.Size = new System.Drawing.Size(80, 26);
            this.equalsSignBtn.TabIndex = 36;
            this.equalsSignBtn.Text = "=";
            this.equalsSignBtn.UseVisualStyleBackColor = true;
            this.equalsSignBtn.Click += new System.EventHandler(this.equalsSignBtn_Click);
            // 
            // dotBtn
            // 
            this.dotBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.dotBtn.Location = new System.Drawing.Point(211, 330);
            this.dotBtn.Name = "dotBtn";
            this.dotBtn.Size = new System.Drawing.Size(80, 26);
            this.dotBtn.TabIndex = 41;
            this.dotBtn.Text = ".";
            this.dotBtn.UseVisualStyleBackColor = true;
            this.dotBtn.Click += new System.EventHandler(this.button_click);
            // 
            // zeroBtn
            // 
            this.zeroBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.zeroBtn.Location = new System.Drawing.Point(12, 330);
            this.zeroBtn.Name = "zeroBtn";
            this.zeroBtn.Size = new System.Drawing.Size(181, 26);
            this.zeroBtn.TabIndex = 40;
            this.zeroBtn.Text = "0";
            this.zeroBtn.UseVisualStyleBackColor = true;
            this.zeroBtn.Click += new System.EventHandler(this.button_click);
            // 
            // box_Content
            // 
            this.box_Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 29F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.box_Content.Location = new System.Drawing.Point(12, 31);
            this.box_Content.Multiline = true;
            this.box_Content.Name = "box_Content";
            this.box_Content.Size = new System.Drawing.Size(380, 47);
            this.box_Content.TabIndex = 42;
            this.box_Content.Text = "0";
            this.box_Content.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblCurrentOperation
            // 
            this.lblCurrentOperation.AutoSize = true;
            this.lblCurrentOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.lblCurrentOperation.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblCurrentOperation.Location = new System.Drawing.Point(22, 4);
            this.lblCurrentOperation.Name = "lblCurrentOperation";
            this.lblCurrentOperation.Size = new System.Drawing.Size(0, 24);
            this.lblCurrentOperation.TabIndex = 43;
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(403, 375);
            this.Controls.Add(this.lblCurrentOperation);
            this.Controls.Add(this.box_Content);
            this.Controls.Add(this.dotBtn);
            this.Controls.Add(this.zeroBtn);
            this.Controls.Add(this.minusSignBtn);
            this.Controls.Add(this.plusSign);
            this.Controls.Add(this.equalsSignBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.divisionSignBtn);
            this.Controls.Add(this.productSignBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.clearEntryBtn);
            this.Controls.Add(this.moduloSignBtn);
            this.Controls.Add(this.sqrtBtn);
            this.Controls.Add(this.nineBtn);
            this.Controls.Add(this.powerOfBtn);
            this.Controls.Add(this.eightBtn);
            this.Controls.Add(this.sevenBtn);
            this.Controls.Add(this.fractionSignBtn);
            this.Controls.Add(this.sixBtn);
            this.Controls.Add(this.threeBtn);
            this.Controls.Add(this.fiveBtn);
            this.Controls.Add(this.twoBtn);
            this.Controls.Add(this.oneBtn);
            this.Controls.Add(this.fourBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "mainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculadora Grupo 8 - Programacion III -  TUP 2020";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sixBtn;
        private System.Windows.Forms.Button threeBtn;
        private System.Windows.Forms.Button fiveBtn;
        private System.Windows.Forms.Button twoBtn;
        private System.Windows.Forms.Button oneBtn;
        private System.Windows.Forms.Button fourBtn;
        private System.Windows.Forms.Button sqrtBtn;
        private System.Windows.Forms.Button nineBtn;
        private System.Windows.Forms.Button powerOfBtn;
        private System.Windows.Forms.Button eightBtn;
        private System.Windows.Forms.Button sevenBtn;
        private System.Windows.Forms.Button fractionSignBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button clearEntryBtn;
        private System.Windows.Forms.Button moduloSignBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button divisionSignBtn;
        private System.Windows.Forms.Button productSignBtn;
        private System.Windows.Forms.Button minusSignBtn;
        private System.Windows.Forms.Button plusSign;
        private System.Windows.Forms.Button equalsSignBtn;
        private System.Windows.Forms.Button dotBtn;
        private System.Windows.Forms.Button zeroBtn;
        private System.Windows.Forms.TextBox box_Content;
        private System.Windows.Forms.Label lblCurrentOperation;
    }
}

