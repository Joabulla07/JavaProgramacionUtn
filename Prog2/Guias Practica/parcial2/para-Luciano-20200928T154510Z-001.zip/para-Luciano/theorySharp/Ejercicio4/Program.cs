﻿using System;

namespace Ejercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[40];
            
        }
    }
}